import { formatAmt, humanError, isAddr, parseUnits, short, usd, usdToHuman } from './lib/format.js'
import { qrcodegen } from './lib/qrcodegen.js'
import { quoteUsdPrice } from './lib/market.js'
import { ADDR } from './lib/constants.js'

const AMOUNTS = ['5', '10', '20', '50', '100', '200']
const OLD_BNB_AMOUNTS = new Set(['0.01', '0.05', '0.1', '0.5'])
const PCTS = [25, 50, 100]
const TABS = [
  ['holdings', '持仓'],
  ['hot', '热门'],
  ['new', '最新'],
  ['progress', '进度'],
  ['graduated', '毕业'],
  ['fair', '打新'],
]

function el(tag, className, text) {
  const node = document.createElement(tag)
  if (className) node.className = className
  if (text != null) node.textContent = text
  return node
}

function hue(addr) {
  let n = 0
  for (const ch of String(addr || '').slice(2, 8)) n = (n * 33 + ch.charCodeAt(0)) >>> 0
  return n % 360
}

let port
let seq = 0
const pending = new Map()

function ensurePort() {
  if (port) return port
  port = chrome.runtime.connect({ name: 'gq' })
  port.onMessage.addListener((msg) => {
    const job = pending.get(msg.id)
    if (!job) return
    if (msg.progress) {
      job.onProgress?.(msg.progress)
      return
    }
    pending.delete(msg.id)
    if (msg.error) job.reject(new Error(msg.error))
    else job.resolve(msg.result)
  })
  port.onDisconnect.addListener(() => {
    port = null
    for (const job of pending.values()) job.reject(new Error('扩展后台断开了，请重试'))
    pending.clear()
  })
  return port
}

function call(action, payload, onProgress) {
  const id = ++seq
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject, onProgress })
    try {
      ensurePort().postMessage({ id, action, payload })
    } catch (err) {
      pending.delete(id)
      reject(err)
    }
  })
}

export function mount(root, { variant }) {
  const state = {
    variant,
    open: variant === 'popup',
    tokens: [],
    tab: 'hot',
    q: '',
    looking: false,
    amount: '10',
    slippage: '1',
    sellPct: 100,
    account: null,
    holdings: new Map(),
    pnl: new Map(),
    holdingsReady: false,
    capLeft: new Map(),
    capToken: 0,
    busy: false,
    status: '正在拉取代币…',
    error: '',
    sheet: null,
  }

  const wrap = el('div', variant === 'dock' ? 'gq-dock' : 'gq-fill')
  const launcher = el('button', 'gq-launcher', '买卖')
  launcher.type = 'button'
  launcher.title = 'Tick 快速买卖'
  const panel = el('div', 'gq gq-panel')
  if (variant === 'popup') {
    wrap.append(panel)
  } else {
    launcher.setAttribute('aria-expanded', 'false')
    wrap.append(launcher, panel)
    panel.hidden = true
  }
  root.append(wrap)

  const head = el('div', 'gq-head')
  const brand = el('div', 'gq-brand')
  brand.append(el('b', '', 'TICK'), el('span', '', '快速买卖'))
  const conn = el('button', 'gq-conn', '连接')
  conn.type = 'button'
  const refresh = el('button', 'gq-text gq-refresh', '刷新')
  refresh.type = 'button'
  refresh.title = '重新读取持仓和列表'
  refresh.addEventListener('click', () => reload())
  const tools = el('div', 'gq-tools')
  tools.append(refresh, conn)
  head.append(brand, tools)

  const meta = el('div', 'gq-meta')
  const loginBox = el('div', 'gq-login')
  loginBox.hidden = true
  const loginText = el('p', 'gq-login-text')
  const qrBox = el('div', 'gq-qr')
  const pair = el('p', 'gq-pair')
  const renew = el('button', 'gq-chip', '换一个二维码')
  renew.type = 'button'
  loginBox.append(loginText, qrBox, pair, renew)
  const prefs = el('div', 'gq-prefs')
  const amountInput = el('input', 'gq-input')
  amountInput.inputMode = 'decimal'
  amountInput.autocomplete = 'off'
  amountInput.spellcheck = false
  amountInput.setAttribute('aria-label', '买入金额，单位 U')
  const slipInput = el('input', 'gq-input gq-input-short')
  slipInput.inputMode = 'decimal'
  slipInput.autocomplete = 'off'
  slipInput.setAttribute('aria-label', '滑点百分比')
  slipInput.value = '1'
  const amountField = el('label', 'gq-field')
  amountField.append(el('span', '', '买入 (U)'), amountInput)
  const slipField = el('label', 'gq-field')
  const slipName = el('span', '', '滑点 %')
  slipName.title = '报价之后，成交价最多允许再差这么多。差得更多就取消这笔，避免买贵或卖便宜。'
  slipInput.title = slipName.title
  slipField.append(slipName, slipInput)
  const amountChips = el('div', 'gq-chips')
  const pctChips = el('div', 'gq-chips')
  prefs.append(amountField, slipField, amountChips, el('div', 'gq-label', '卖出比例'), pctChips)

  const tabs = el('div', 'gq-tabs')
  const searchBox = el('div', 'gq-searchbox')
  const search = el('input', 'gq-search')
  search.placeholder = '搜索符号、名字，或粘贴 0x 合约地址'
  search.autocomplete = 'off'
  search.spellcheck = false
  const searchClear = el('button', 'gq-search-clear', '×')
  searchClear.type = 'button'
  searchClear.hidden = true
  searchClear.title = '清空搜索'
  searchBox.append(search, searchClear)
  const list = el('div', 'gq-list')
  const status = el('div', 'gq-status')
  const sheet = el('div', 'gq-sheet')
  sheet.hidden = true
  const foot = el('p', 'gq-foot', '持仓只列 Gang 代币。USDC、USDT 和 BNB 不会出现在这里。买入按 U 计价。')

  panel.append(head, meta, loginBox, prefs, tabs, searchBox, list, status, sheet, foot)

  let loginGen = 0
  let loginBusy = false

  function sellPnl(row, bal) {
    const addr = String(row.address || '').toLowerCase()
    const full = Number(state.pnl.get(addr) ?? row.unrealizedUsd)
    if (!Number.isFinite(full) || !(bal > 0n)) return null
    const pct = Math.min(100, Math.max(1, state.sellPct)) / 100
    const n = full * pct
    const abs = usd(Math.abs(n))
    const dir = Math.abs(n) < 0.005 ? 'flat' : n > 0 ? 'up' : 'down'
    const text = dir === 'flat' ? '持平' : dir === 'up' ? `盈 ${abs}` : `亏 ${abs}`
    const how = state.sellPct === 100 ? '全部卖掉' : `卖掉 ${state.sellPct}%`
    return {
      dir,
      text,
      title: `按拿到这些币时的成本估算，${how}大约${dir === 'up' ? '赚' : dir === 'down' ? '亏' : '持平'}。成交还会再扣手续费和滑点。`,
    }
  }

  function holdUsd(row, bal) {
    if (row.priceUsd > 0 && bal > 0n) {
      const n = Number(bal / 10n ** 12n) / 1e6
      if (n > 0) return n * row.priceUsd
    }
    return Number(row.valueUsd) || 0
  }

  function heldRows() {
    const dust = 10n ** 15n
    return state.tokens.filter((row) => (state.holdings.get(row.address) || 0n) >= dust)
  }

  function bnbFx() {
    for (const row of state.tokens) if (row.bnbUsd > 0) return row.bnbUsd
    return 0
  }

  function setBusy(on) {
    state.busy = on
    panel.classList.toggle('is-busy', on)
    const go = sheet.querySelector('.gq-go')
    if (go) go.disabled = on
  }

  function setStatus(text) {
    state.status = text || ''
    status.textContent = state.error || state.status
    status.classList.toggle('is-error', Boolean(state.error))
  }

  function needsLogin(message) {
    return /还没登录|not logged in|未登录/i.test(String(message || ''))
  }

  function fail(err) {
    const message = humanError(err)
    state.error = message
    setStatus('')
    if (!loginBusy && needsLogin(message) && state.account?.account) {
      state.account.localOff = true
      paintAccount()
    }
  }

  function drawQr(url) {
    const Qr = qrcodegen.QrCode
    const qr = Qr.encodeText(url, Qr.Ecc.MEDIUM)
    const n = qr.size
    const quiet = 4
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
    svg.setAttribute('viewBox', `0 0 ${n + quiet * 2} ${n + quiet * 2}`)
    svg.setAttribute('width', '180')
    svg.setAttribute('height', '180')
    svg.setAttribute('role', 'img')
    svg.setAttribute('aria-label', '币安 App 登录二维码')
    const bg = document.createElementNS(svg.namespaceURI, 'rect')
    bg.setAttribute('width', String(n + quiet * 2))
    bg.setAttribute('height', String(n + quiet * 2))
    bg.setAttribute('fill', '#fff')
    svg.append(bg)
    for (let y = 0; y < n; y++) {
      for (let x = 0; x < n; x++) {
        if (!qr.getModule(x, y)) continue
        const cell = document.createElementNS(svg.namespaceURI, 'rect')
        cell.setAttribute('x', String(x + quiet))
        cell.setAttribute('y', String(y + quiet))
        cell.setAttribute('width', '1')
        cell.setAttribute('height', '1')
        cell.setAttribute('fill', '#111')
        svg.append(cell)
      }
    }
    qrBox.replaceChildren(svg)
  }

  function writeLoginCopy() {
    const addr = state.account?.account || ''
    loginText.replaceChildren('这个地址是上次记住的 Agent 钱包，持仓还在这里。本机登录已经掉了，买卖发不出去。用币安 App 扫这个二维码重新登录。')
    if (addr) loginText.append(document.createElement('br'), el('span', 'gq-addr', addr))
  }

  async function startLogin() {
    if (!state.account?.account || !state.account.localOff || loginBusy) return
    loginBusy = true
    const gen = ++loginGen
    writeLoginCopy()
    pair.classList.remove('is-error')
    pair.textContent = '正在生成二维码…'
    qrBox.replaceChildren()
    try {
      const ticket = await call('LOGIN')
      if (gen !== loginGen) return
      if (ticket.already) {
        await finishLogin(ticket.address)
        return
      }
      drawQr(ticket.url)
      pair.textContent = ticket.pairingCode ? `配对码 ${ticket.pairingCode}` : '用币安 App 扫这个二维码'
      const done = await call('LOGIN_WAIT', { qrCodeId: ticket.qrCodeId })
      if (gen !== loginGen) return
      await finishLogin(done.address)
    } catch (err) {
      if (gen !== loginGen) return
      pair.classList.add('is-error')
      pair.textContent = humanError(err)
    } finally {
      if (gen === loginGen) loginBusy = false
    }
  }

  async function finishLogin(address) {
    const want = String(state.account?.account || '')
    if (address && want && address.toLowerCase() !== want.toLowerCase()) {
      throw new Error(`本机登录的是 ${address}，持仓在 ${want}`)
    }
    const out = await call('SWITCH', { account: want })
    state.account = { ...state.account, ...out, signer: out.account, via: 'baw', localOff: false }
    loginBox.hidden = true
    clearError()
    paintAccount()
    setStatus('本机 Agent 已重新登录。可以再点一次确认。')
  }

  async function finishScan(via, done) {
    let out
    if (via === 'baw') out = await call('USE_BAW')
    else {
      try {
        out = await call('CONNECT')
      } catch {
        await new Promise((resolve) => setTimeout(resolve, 800))
        out = await call('CONNECT')
      }
    }
    if (done?.handle && !out.handle) out.handle = done.handle
    state.account = { ...out, localOff: false }
    loginBox.hidden = true
    clearError()
    state.holdingsReady = false
    state.tab = 'holdings'
    paintAccount()
    paintTabs()
    setStatus(via === 'baw' ? '本机 Agent 已登录。买卖在币安 App 里确认。' : '已连上 Agent 钱包')
    await loadHoldings()
  }

  async function startScan() {
    if (loginBusy) return
    loginBusy = true
    const gen = ++loginGen
    loginBox.hidden = false
    loginText.textContent = '用币安 App 扫这个二维码，连接你的 Agent 钱包。'
    pair.classList.remove('is-error')
    pair.textContent = '正在生成二维码…'
    qrBox.replaceChildren()
    try {
      let ticket
      let via = 'site'
      try {
        ticket = await call('SCAN')
      } catch (siteErr) {
        try {
          ticket = await call('LOGIN')
          via = 'baw'
        } catch {
          throw siteErr
        }
      }
      if (gen !== loginGen) return
      if (ticket.already) {
        await finishScan(via)
        return
      }
      drawQr(ticket.url)
      pair.textContent = ticket.pairingCode ? `配对码 ${ticket.pairingCode}` : '用币安 App 扫这个二维码'
      const done = via === 'baw'
        ? await call('LOGIN_WAIT', { qrCodeId: ticket.qrCodeId })
        : await call('SCAN_WAIT', { uid: ticket.uid })
      if (gen !== loginGen) return
      await finishScan(via, done)
    } catch (err) {
      if (gen !== loginGen) return
      pair.classList.add('is-error')
      pair.textContent = humanError(err)
    } finally {
      if (gen === loginGen) loginBusy = false
    }
  }

  function restartLogin() {
    loginGen += 1
    loginBusy = false
    if (state.account) state.account.localOff = true
    startLogin()
  }

  renew.addEventListener('click', () => {
    loginGen += 1
    loginBusy = false
    if (state.account?.localOff) startLogin()
    else startScan()
  })

  function ensureLogin() {
    if (loginBusy) return
    if (!state.account?.localOff) {
      loginBox.hidden = true
      return
    }
    loginBox.hidden = false
    writeLoginCopy()
    startLogin()
  }

  function clearError() {
    state.error = ''
    setStatus(state.status)
  }

  let saveTimer = 0
  function scheduleSave() {
    clearTimeout(saveTimer)
    saveTimer = setTimeout(() => {
      call('SAVE_PREFS', {
        amount: state.amount,
        slippage: state.slippage,
        sellPct: state.sellPct,
      }).catch(() => {})
    }, 250)
  }

  function agentLabel(account) {
    const handle = String(account?.handle || '').trim()
    if (!handle) return short(account?.account)
    return handle.includes('.') ? handle : `${handle}.ai`
  }

  function posWei(text) {
    const s = String(text ?? '').trim()
    if (!s) return 0n
    try { return parseUnits(s, 18) } catch { return 0n }
  }

  function walletMismatch() {
    const signer = String(state.account?.signer || '').toLowerCase()
    const agent = String(state.account?.account || '').toLowerCase()
    return Boolean(agent && signer && signer !== agent && state.account?.via !== 'baw')
  }

  async function adoptAgent(out) {
    state.account = { ...state.account, ...out, signer: out.account, via: 'baw', localOff: false }
    paintAccount()
  }

  async function autoSwitch() {
    if (!walletMismatch()) return false
    try {
      const out = await call('SWITCH', { account: state.account.account })
      await adoptAgent(out)
      setStatus('已切换到 Agent 钱包。买卖在币安 App 里确认。')
      return true
    } catch {
      return false
    }
  }

  async function switchWallet() {
    if (state.busy || !state.account?.account) return
    setBusy(true)
    clearError()
    setStatus('正在接上本机已登录的 Agent 钱包')
    try {
      const out = await call('SWITCH', { account: state.account.account })
      await adoptAgent(out)
      setStatus('已切换到 Agent 钱包。之后买卖在币安 App 里确认。')
    } catch (err) {
      fail(err)
    } finally {
      setBusy(false)
    }
  }

  function paintAccount() {
    meta.replaceChildren()
    if (!state.account) {
      meta.append(el('span', 'gq-dim', '未连接 · 用币安 App 扫码'))
      conn.textContent = '扫码登录'
      return
    }
    const who = el('span', 'gq-addr', agentLabel(state.account))
    who.title = state.account.account
    const badge = el('span', state.account.agent ? 'gq-badge is-on' : 'gq-badge', state.account.agent ? 'Agent 钱包' : '当前钱包')
    const bnbAmount = Number(String(state.account.bnb || '').replace(/,/g, ''))
    const fx = bnbFx()
    const approx = bnbAmount > 0 && fx > 0 ? ` ≈ ${usd(bnbAmount * fx)}` : ''
    const bnb = el('span', 'gq-dim', `${state.account.bnb || '—'} BNB${approx}`)
    if (fx > 0) bnb.title = `按 1 BNB ≈ ${usd(fx)} 估算`
    const signer = String(state.account.signer || '').toLowerCase()
    const agent = String(state.account.account || '').toLowerCase()
    const out = el('button', 'gq-text', '断开')
    out.type = 'button'
    out.addEventListener('click', async () => {
      await call('DISCONNECT').catch(() => {})
      state.account = null
      resetCap()
      state.holdings = new Map()
      state.holdingsReady = false
      paintAccount()
      paintTabs()
      paintList()
    })
    meta.append(who, badge, bnb)
    if (!signer || signer !== agent) {
      const sw = el('button', 'gq-switch', '切换到 Agent')
      sw.type = 'button'
      sw.title = state.account.account
      sw.addEventListener('click', () => switchWallet())
      meta.append(sw)
    }
    meta.append(out)
    conn.textContent = state.account.localOff ? '未登录' : '已连接'
    ensureLogin()
  }

  function paintChips() {
    amountChips.replaceChildren()
    for (const n of AMOUNTS) {
      const b = el('button', state.amount === n ? 'gq-chip on' : 'gq-chip', `${n}U`)
      b.type = 'button'
      b.addEventListener('click', () => {
        state.amount = n
        amountInput.value = n
        scheduleSave()
        paintChips()
        paintList()
      })
      amountChips.append(b)
    }
    pctChips.replaceChildren()
    for (const n of PCTS) {
      const b = el('button', state.sellPct === n ? 'gq-chip on' : 'gq-chip', `${n}%`)
      b.type = 'button'
      b.addEventListener('click', () => {
        state.sellPct = n
        scheduleSave()
        paintChips()
        paintTabs()
        paintList()
      })
      pctChips.append(b)
    }
  }

  function holdingCount() {
    let n = 0
    for (const v of state.holdings.values()) if (v > 0n) n += 1
    return n
  }

  function paintTabs() {
    tabs.replaceChildren()
    for (const [id, label] of TABS) {
      const text = id === 'holdings' && state.holdingsReady ? `${label} ${holdingCount()}` : label
      const b = el('button', state.tab === id ? 'gq-tab on' : 'gq-tab', text)
      b.type = 'button'
      b.addEventListener('click', async () => {
        state.tab = id
        paintTabs()
        if (id === 'holdings') await loadHoldings()
        paintList()
      })
      tabs.append(b)
    }
    if (state.tab === 'holdings' && holdingCount()) {
      const all = el('button', 'gq-direct', `一键卖出 ${holdingCount()} 个`)
      all.type = 'button'
      all.title = `按 ${state.sellPct}% 卖出下面每一个持仓，点下去就弹出钱包`
      all.addEventListener('click', () => sellHeld())
      tabs.append(all)
    }
  }

  function rows() {
    let listRows = state.tokens
    const q = state.q.trim().toLowerCase()
    const byAddress = /^0x[0-9a-f]{4,}$/.test(q)
    if (!byAddress) {
      if (state.tab === 'progress') listRows = listRows.filter((r) => !r.graduated && r.progressPct < 100)
      else if (state.tab === 'graduated') listRows = listRows.filter((r) => r.graduated)
      else if (state.tab === 'fair') listRows = listRows.filter((r) => r.track === 'fair')
      else if (state.tab === 'holdings') listRows = listRows.filter((r) => (state.holdings.get(r.address) || 0n) > 0n)
    }
    if (q) {
      listRows = listRows.filter((r) => {
        const symbol = String(r.symbol || '').toLowerCase()
        const name = String(r.name || '').toLowerCase()
        const quote = String(r.quoteSymbol || '').toLowerCase()
        const address = String(r.address || '').toLowerCase()
        return symbol.includes(q) || name.includes(q) || quote.includes(q) || address.includes(q)
      })
    }
    const copy = listRows.slice()
    const num = (v) => Number(v) || 0
    const saleFirst = (a, b, rest) => {
      const sa = a.track === 'fair' && !a.graduated
      const sb = b.track === 'fair' && !b.graduated
      if (sa !== sb) return sa ? -1 : 1
      return rest(a, b)
    }
    if (state.tab === 'new') copy.sort((a, b) => saleFirst(a, b, (x, y) => num(y.createdAt) - num(x.createdAt)))
    else if (state.tab === 'progress') copy.sort((a, b) => saleFirst(a, b, (x, y) => num(y.progressPct) - num(x.progressPct)))
    else if (state.tab === 'graduated') copy.sort((a, b) => num(b.graduatedAt) - num(a.graduatedAt))
    else if (state.tab === 'fair') {
      copy.sort((a, b) => {
        if (a.graduated !== b.graduated) return a.graduated ? 1 : -1
        if (!a.graduated) return num(b.progressPct) - num(a.progressPct) || num(b.createdAt) - num(a.createdAt)
        return num(b.graduatedAt) - num(a.graduatedAt)
      })
    }
    else if (state.tab === 'holdings') {
      copy.sort((a, b) => {
        const av = holdUsd(a, state.holdings.get(a.address) || 0n)
        const bv = holdUsd(b, state.holdings.get(b.address) || 0n)
        return bv - av
      })
    } else {
      copy.sort((a, b) => num(b.volUsd) - num(a.volUsd) || num(b.lastTradeAt) - num(a.lastTradeAt))
      // $TICK first, then the GANG platform token.
      const pinned = ['0xc2af5a38362716fcd01503498bde858eb49790f8', '0x0c6302401aa5325c2e36f170f52c00b1d220b405']
      const rank = (row) => {
        const i = pinned.indexOf(String(row.address || '').toLowerCase())
        return i < 0 ? pinned.length : i
      }
      copy.sort((a, b) => rank(a) - rank(b))
    }
    return copy
  }

  function resetCap() {
    state.capToken += 1
    state.capLeft = new Map()
  }

  function moneyGap(n) {
    if (!(n > 0)) return ''
    if (n >= 1e6) return usd(n)
    if (n >= 100) return `$${Math.round(n).toLocaleString('en-US')}`
    return usd(n)
  }

  function quotePx(row) {
    return quoteUsdPrice(row, bnbFx()) || (Number(row.quoteUsd) > 0 ? Number(row.quoteUsd) : 0)
  }

  function quoteHuman(quote, dec) {
    const base = 10n ** BigInt(dec)
    const whole = quote / base
    const frac = quote % base
    const cut = dec > 6 ? 10n ** BigInt(dec - 6) : 1n
    const fracScale = dec > 6 ? 1e6 : 10 ** dec
    return Number(whole) + Number(frac / cut) / fracScale
  }

  function capLabel(row) {
    const mine = state.capLeft.get(row.address)
    if (!mine || mine.pending || mine.miss) return null
    if (mine.full) return { text: '已买满', title: '这个钱包在这条内盘已经到 1% 上限' }
    let quote
    try { quote = BigInt(mine.quote) } catch { return null }
    if (quote <= 0n) return null
    const dec = Number(mine.decimals) > 0 ? Number(mine.decimals) : 18
    const px = quotePx(row)
    if (!(px > 0)) return null
    const left = quoteHuman(quote, dec) * px
    if (!(left > 0)) return null
    const text = moneyGap(left)
    if (!text) return null
    return { text: `买满还差 ${text}`, title: `这个钱包离 1% 持仓上限大约还要花 ${text}` }
  }

  function loadCapLeft() {
    const account = state.account?.account
    if (!isAddr(account)) return
    const open = rows().filter((row) => !row.graduated && !state.capLeft.has(row.address))
    const fast = open.filter((row) => row.v2Launchpad)
    const need = (fast.length ? fast : open).slice(0, fast.length ? 24 : 8)
    if (!need.length) return
    const token = state.capToken
    for (const row of need) state.capLeft.set(row.address, { pending: true })
    const mark = need.map((row) => row.address)
    call('CAP_LEFT', {
      account,
      tokens: need.map((row) => ({ address: row.address, hint: row.v2Launchpad || '' })),
    }).then((result) => {
      if (token !== state.capToken) return
      const got = new Map((result?.rows || []).map((row) => [row.address, row]))
      for (const addr of mark) state.capLeft.set(addr, got.get(addr) || { miss: true })
      paintList()
    }).catch(() => {
      if (token !== state.capToken) return
      for (const addr of mark) state.capLeft.delete(addr)
    })
  }

  function paintList() {
    const top = list.scrollTop
    const data = rows()
    list.replaceChildren()
    if (!state.tokens.length && !state.error) {
      list.append(el('div', 'gq-empty', '还没有代币'))
      return
    }
    if (!data.length) {
      const empty = state.looking
        ? '查询合约…'
        : state.q.trim()
        ? `没有找到「${state.q.trim()}」`
        : state.tab === 'holdings'
          ? (state.account ? '这个地址没有 Gang 代币' : '点右上角「扫码登录」，用币安 App 连接 Agent 钱包')
          : state.tab === 'fair'
            ? '还没有打新'
            : '没有匹配的代币'
      list.append(el('div', 'gq-empty', empty))
      return
    }
    for (const row of data) {
      const item = el('article', 'gq-row')
      const av = el('div', 'gq-av')
      av.style.background = `hsl(${hue(row.address)} 42% 18%)`
      if (row.logo) {
        const img = el('img')
        img.alt = ''
        img.src = row.logo
        img.addEventListener('error', () => img.remove())
        av.append(img)
      }
      av.append(el('span', '', (row.symbol || '?').slice(0, 1)))
      const main = el('div', 'gq-main')
      const title = el('div', 'gq-title')
      const link = el('a', 'gq-sym', row.symbol || short(row.address))
      link.href = `https://gang.fun/token/${row.address}`
      link.target = '_blank'
      link.rel = 'noreferrer'
      title.append(link)
      if (row.track === 'v3') title.append(el('i', 'gq-tag', row.buyTaxBps > 0 ? `税 ${row.buyTaxBps / 100}%` : '税收'))
      else if (row.taxed) title.append(el('i', 'gq-tag', '税'))
      if (row.track === 'fair' && !row.graduated) title.append(el('i', 'gq-tag', '打新'))
      if (row.graduated) title.append(el('i', 'gq-tag', '毕业'))
      title.append(el('b', 'gq-mcap', usd(row.mcapUsd)))
      const sub = el('div', 'gq-sub')
      const bal = state.holdings.get(row.address) || 0n
      const showQty = state.tab === 'holdings' && bal > 0n
      const bits = [row.name || row.quoteSymbol]
      const mine = (row.graduated || row.track === 'v3' || row.track === 'fair') ? null : capLabel(row)
      if (!row.graduated) bits.push(`${Math.max(0, row.progressPct).toFixed(0)}%`)
      if (mine) bits.push(mine.text)
      bits.push(row.quoteSymbol)
      sub.textContent = bits.filter(Boolean).join(' · ')
      if (mine) sub.title = mine.title
      const pnl = showQty ? sellPnl(row, bal) : null
      const bar = el('i', 'gq-bar')
      const fill = el('i')
      fill.style.width = `${row.graduated ? 100 : Math.max(0, Math.min(100, row.progressPct))}%`
      bar.append(fill)
      main.append(title, sub, bar)
      const actions = el('div', 'gq-actions')
      const buy = el('button', 'gq-buy', `买 ${state.amount}U`)
      buy.type = 'button'
      buy.title = `用 ${state.amount} U 直接买入，下一步是钱包签名`
      buy.addEventListener('click', () => direct('buy', row))
      const sell = el('button', 'gq-sell', state.sellPct === 100 ? '卖出' : `卖 ${state.sellPct}%`)
      sell.type = 'button'
      sell.title = '直接卖出持仓，下一步是钱包签名'
      sell.addEventListener('click', () => direct('sell', row))
      actions.append(buy, sell)
      if (showQty) {
        item.classList.add('has-qty')
        const qty = el('div', 'gq-qty')
        qty.append(el('b', '', formatAmt(bal, 18)))
        const worth = holdUsd(row, bal)
        qty.append(el('span', '', worth > 0 ? `市值 ${usd(worth)}` : '市值 —'))
        const mark = el('span', `gq-pnl ${pnl?.dir || 'flat'}`, pnl ? `盈亏 ${pnl.text}` : '盈亏 —')
        mark.title = pnl?.title || '没有买入成本，算不出卖掉后是赚是亏'
        qty.append(mark)
        item.append(av, main, qty, actions)
      } else {
        item.append(av, main, actions)
      }
      list.append(item)
    }
    list.scrollTop = top
    loadCapLeft()
  }

  function closeSheet() {
    state.sheet = null
    sheet.hidden = true
    sheet.replaceChildren()
  }

  function paintSheet() {
    const current = state.sheet
    sheet.replaceChildren()
    if (!current) {
      sheet.hidden = true
      return
    }
    sheet.hidden = false
    sheet.append(el('div', 'gq-sheet-title', current.title))
    const lines = el('div', 'gq-lines')
    for (const [k, v] of current.lines || []) {
      const line = el('div', 'gq-line')
      line.append(el('span', '', k), el('b', '', v))
      lines.append(line)
    }
    if (current.hashes?.length) {
      for (const hash of current.hashes) {
        const a = el('a', 'gq-hash', short(hash))
        a.href = `https://bscscan.com/tx/${hash}`
        a.target = '_blank'
        a.rel = 'noreferrer'
        lines.append(a)
      }
    }
    sheet.append(lines)
    const actions = el('div', 'gq-sheet-actions')
    if (!current.done) {
      const stop = el('button', 'gq-stop', '取消')
      stop.type = 'button'
      stop.disabled = state.busy
      stop.addEventListener('click', () => { if (!state.busy) closeSheet() })
      const go = el('button', 'gq-go')
      go.type = 'button'
      go.disabled = state.busy
      if (state.busy) {
        go.classList.add('is-loading')
        go.append(el('i', 'gq-spin'), document.createTextNode(current.busyLabel || '处理中…'))
      } else {
        go.textContent = current.confirm || '确认'
      }
      go.addEventListener('click', () => current.onGo?.())
      actions.append(stop, go)
    } else {
      const stop = el('button', 'gq-go', '完成')
      stop.type = 'button'
      stop.addEventListener('click', () => closeSheet())
      actions.append(stop)
    }
    sheet.append(actions)
  }

  async function reload() {
    if (state.busy) return
    setBusy(true)
    clearError()
    setStatus('正在刷新')
    try {
      resetCap()
      const fresh = await call('REFRESH')
      if (fresh?.tokens?.length) {
        const seen = new Set(fresh.tokens.map((row) => row.address))
        const extras = state.tokens.filter((row) => row.address && !seen.has(row.address))
        state.tokens = [...extras, ...fresh.tokens]
      }
      if (state.account?.account) {
        const next = await call('STATUS', { account: state.account.account }).catch(() => null)
        if (next) {
          state.account = {
            ...state.account,
            ...next,
            handle: state.account.handle || '',
            agent: state.account.agent,
            signer: state.account.signer || '',
            via: state.account.via || '',
          }
        }
        state.holdingsReady = false
        paintAccount()
        await loadHoldings()
      } else {
        setStatus(`${state.tokens.length} 个代币`)
        paintTabs()
        paintList()
      }
    } catch (err) {
      fail(err)
    } finally {
      setBusy(false)
    }
  }

  function humanAmt(bal) {
    return Number(bal / 10n ** 12n) / 1e6
  }

  function consumeLots(lots, qty) {
    let left = qty
    while (left > 1e-8 && lots.length) {
      const lot = lots[0]
      const take = Math.min(lot.qty, left)
      if (lot.qty > 0 && lot.usd != null) lot.usd *= (lot.qty - take) / lot.qty
      lot.qty -= take
      left -= take
      if (lot.qty <= 1e-6) lots.shift()
    }
  }

  /** Cost of tokens the indexer has no buy price for, using Gang trades. Quote received (卖别的币换来的 GANG) counts at the price when it arrived. */
  async function fetchTradeCosts(account, holdings) {
    const trades = []
    let offset = 0
    for (let i = 0; i < 8; i++) {
      const res = await fetch(`https://gang.fun/api/agents/${encodeURIComponent(account)}/trades?limit=100&offset=${offset}`)
      if (!res.ok) break
      const data = await res.json()
      trades.push(...(data.items || []))
      if (!data.hasMore) break
      offset = data.nextOffset ?? offset + (data.items || []).length
    }
    const bySymbol = new Map([['GANG', ADDR.platform.toLowerCase()]])
    for (const row of state.tokens) {
      const sym = String(row.symbol || '').toUpperCase()
      if (sym && sym !== 'BNB' && sym !== 'WBNB' && !bySymbol.has(sym)) bySymbol.set(sym, row.address)
      const q = String(row.quoteSymbol || '').toUpperCase()
      const qa = String(row.quoteAddress || '').toLowerCase()
      if (q && q !== 'BNB' && q !== 'WBNB' && isAddr(qa) && !bySymbol.has(q)) bySymbol.set(q, qa)
    }
    const flows = new Map()
    const add = (addr, flow) => {
      if (!addr || !holdings.has(addr) || !(flow.qty > 0)) return
      if (!flows.has(addr)) flows.set(addr, [])
      flows.get(addr).push(flow)
    }
    for (const t of trades) {
      const token = String(t.token || '').toLowerCase()
      const quote = bySymbol.get(String(t.amountSymbol || '').toUpperCase()) || ''
      const qtyTokens = Number(t.tokens)
      const qtyQuote = Number(t.amount)
      const usd = Number(t.amountUsd)
      const ts = Number(t.ts) || 0
      const cost = Number.isFinite(usd) ? usd : null
      if (t.side === 'buy') {
        add(token, { ts, dir: 1, qty: qtyTokens, usd: cost })
        if (quote && quote !== token) add(quote, { ts, dir: -1, qty: qtyQuote, usd: cost })
      } else if (t.side === 'sell') {
        add(token, { ts, dir: -1, qty: qtyTokens, usd: cost })
        if (quote && quote !== token) add(quote, { ts, dir: 1, qty: qtyQuote, usd: cost })
      }
    }
    const costs = new Map()
    for (const [addr, list] of flows) {
      const target = humanAmt(holdings.get(addr) || 0n)
      if (!(target > 0)) continue
      const lots = []
      list.sort((a, b) => a.ts - b.ts || b.dir - a.dir)
      for (const flow of list) {
        if (flow.dir > 0) lots.push({ qty: flow.qty, usd: flow.usd })
        else consumeLots(lots, flow.qty)
      }
      const known = lots.reduce((sum, lot) => sum + lot.qty, 0)
      if (!(known > 0) || target > known * 1.002 + 0.01) continue
      if (known - target > 0.01) consumeLots(lots, known - target)
      if (!lots.length || lots.some((lot) => lot.usd == null)) continue
      const left = lots.reduce((sum, lot) => sum + lot.qty, 0)
      if (left < target * 0.99) continue
      costs.set(addr, lots.reduce((sum, lot) => sum + lot.usd, 0))
    }
    return costs
  }

  async function fetchIndexerPnl(account) {
    const map = new Map()
    let offset = 0
    for (let i = 0; i < 4; i++) {
      const res = await fetch(`https://gang.fun/api/agents/${encodeURIComponent(account)}/positions?limit=200&offset=${offset}`)
      if (!res.ok) break
      const data = await res.json()
      for (const item of data.items || []) {
        const addr = String(item.address || '').toLowerCase()
        const n = Number(item.unrealizedUsd)
        if (addr && Number.isFinite(n)) map.set(addr, n)
      }
      if (!data.hasMore) break
      offset = data.nextOffset ?? offset + (data.items || []).length
    }
    return map
  }

  async function fetchWalletPnl(account) {
    const map = new Map()
    let offset = 0
    for (let page = 0; page < 6; page++) {
      const url = `https://web3.binance.com/bapi/defi/v3/public/wallet-direct/buw/wallet/address/pnl/active-position-list?address=${encodeURIComponent(account)}&chainId=56&offset=${offset}`
      const res = await fetch(url, { headers: { Accept: 'application/json', clienttype: 'web', clientversion: '1.2.0' } })
      if (!res.ok) break
      const json = await res.json()
      const batch = json?.data?.list || []
      if (!batch.length) break
      for (const item of batch) {
        const addr = String(item.contractAddress || '').toLowerCase()
        const qty = Number(item.remainQty)
        const price = Number(item.price)
        const avg = Number(item.avgPrice)
        if (!addr || !(qty > 0) || !(price > 0) || !(avg > 0)) continue
        map.set(addr, (price - avg) * qty)
      }
      offset += batch.length
      if (batch.length < 10) break
    }
    return map
  }

  async function loadHoldings() {
    if (!state.account || state.holdingsReady) return
    resetCap()
    setStatus('正在读取你买过的代币…')
    try {
      const account = state.account.account
      const [book, indexer, wallet] = await Promise.all([
        call('MY_BOOK', { account, tokens: state.tokens }),
        fetchIndexerPnl(account).catch(() => new Map()),
        fetchWalletPnl(account).catch(() => new Map()),
      ])
      const have = new Set(state.tokens.map((row) => row.address))
      for (const row of book?.extra || []) {
        if (row?.address && !have.has(row.address)) state.tokens.push(row)
      }
      const pnl = new Map(wallet)
      for (const [addr, n] of indexer) pnl.set(addr, n)
      const posBy = new Map()
      for (const row of book?.positions || []) {
        const addr = String(row?.address || '').toLowerCase()
        if (!addr) continue
        posBy.set(addr, row)
        const n = Number(row.unrealizedUsd)
        if (Number.isFinite(n) && !pnl.has(addr)) pnl.set(addr, n)
      }
      for (const row of book?.pnl || []) {
        const addr = String(row?.address || '').toLowerCase()
        const n = Number(row?.unrealizedUsd)
        if (addr && Number.isFinite(n) && !pnl.has(addr)) pnl.set(addr, n)
      }
      state.pnl = pnl
      for (const row of state.tokens) {
        const addr = String(row.address || '').toLowerCase()
        const pos = posBy.get(addr)
        if (pnl.has(addr)) row.unrealizedUsd = pnl.get(addr)
        if (pos?.posBalance) row.posBalance = pos.posBalance
      }
      const holdings = new Map((book?.balances || []).map((row) => [row.address, BigInt(row.balance)]))
      for (const row of book?.positions || []) {
        if (!row?.address || holdings.get(row.address) > 0n) continue
        const bal = posWei(row.posBalance)
        if (bal > 0n) holdings.set(row.address, bal)
      }
      state.holdings = holdings
      const costs = await fetchTradeCosts(account, holdings).catch(() => new Map())
      for (const [addr, cost] of costs) {
        if (pnl.has(addr) || !(cost >= 0)) continue
        const row = state.tokens.find((item) => item.address === addr)
        const worth = row ? holdUsd(row, holdings.get(addr) || 0n) : 0
        if (worth > 0) pnl.set(addr, worth - cost)
      }
      state.pnl = pnl
      state.holdingsReady = true
      clearError()
      const n = holdingCount()
      setStatus(n ? `Gang 持仓 ${n} 个。盈亏在市值下面，买卖要再点一次确认` : '这个地址没有 Gang 代币。USDC、USDT 和 BNB 不在持仓里。')
      paintTabs()
      paintList()
    } catch (err) {
      fail(err)
    }
  }

  async function refreshAccount() {
    if (!state.account) return
    try {
      const prev = state.account
      const next = await call('STATUS', { account: prev.account })
      if (next) state.account = { ...next, handle: prev.handle || '', agent: prev.agent, signer: prev.via === 'baw' ? prev.account : (prev.signer || ''), via: prev.via || '' }
      paintAccount()
    } catch { /* keep the address we had */ }
  }

  async function direct(side, row) {
    if (state.busy) return
    if (!state.account) {
      fail(new Error('先连接 Agent 钱包'))
      return
    }
    clearError()
    closeSheet()
    setBusy(true)
    let amount = state.amount
    let quoteUsd = 0
    const name = row.symbol || short(row.address)
    if (side === 'buy') {
      quoteUsd = quoteUsdPrice(row, bnbFx())
      try {
        amount = usdToHuman(state.amount, quoteUsd)
      } catch (err) {
        setBusy(false)
        fail(err)
        return
      }
      setStatus(`正在报价 ${name}`)
    } else {
      setStatus(`正在报价 ${name}`)
    }
    try {
      const plan = await call('PREVIEW', {
        side,
        account: state.account.account,
        amount,
        usd: side === 'buy' ? state.amount : '',
        quoteUsd,
        slippage: state.slippage,
        pct: state.sellPct,
        row,
      })
      const lines = [...(plan.preview?.lines || [])]
      if (side === 'sell') {
        const pnl = sellPnl(row, state.holdings.get(row.address) || 0n)
        if (pnl) lines.push(['卖出后盈亏', pnl.text])
      }
      state.sheet = {
        title: side === 'buy' ? `确认买入 ${name}` : `确认卖出 ${name}`,
        lines,
        confirm: side === 'buy' ? '确认买入' : '确认卖出',
        onGo: () => confirmTrade(side, row, plan, name, { amount, quoteUsd }),
      }
      setStatus(`先点「${state.sheet.confirm}」，才会进钱包`)
      paintSheet()
    } catch (err) {
      fail(err)
    } finally {
      setBusy(false)
      if (state.sheet && !state.sheet.done) paintSheet()
    }
  }

  function priceMoved(prev, next) {
    try {
      const oldOut = BigInt(prev || '0')
      const newOut = BigInt(next || '0')
      if (oldOut <= 0n || newOut <= 0n || newOut >= oldOut) return false
      const bps = Math.round(Number(state.slippage) * 100)
      const keep = BigInt(Math.max(0, 10000 - (Number.isFinite(bps) ? bps : 100)))
      return newOut * 10000n < oldOut * keep
    } catch {
      return false
    }
  }

  async function confirmTrade(side, row, plan, name, draft) {
    if (state.busy || !state.account) return
    if (state.sheet) state.sheet.busyLabel = side === 'buy' ? '买入中…' : '卖出中…'
    setBusy(true)
    paintSheet()
    clearError()
    try {
      setStatus(`${name} · 正在按最新价格重新报价`)
      const fresh = await call('PREVIEW', {
        side,
        account: state.account.account,
        amount: draft?.amount ?? state.amount,
        usd: side === 'buy' ? state.amount : '',
        quoteUsd: draft?.quoteUsd || 0,
        slippage: state.slippage,
        pct: state.sellPct,
        row,
      })
      if (priceMoved(plan.receive, fresh.receive)) {
        const lines = [...(fresh.preview?.lines || [])]
        if (side === 'sell') {
          const pnl = sellPnl(row, state.holdings.get(row.address) || 0n)
          if (pnl) lines.push(['卖出后盈亏', pnl.text])
        }
        state.sheet = {
          title: side === 'buy' ? `确认买入 ${name}` : `确认卖出 ${name}`,
          lines,
          confirm: side === 'buy' ? '确认买入' : '确认卖出',
          onGo: () => confirmTrade(side, row, fresh, name, draft),
        }
        paintSheet()
        setStatus('价格变了，能拿到的比刚才少。看一眼新报价，再点一次确认。')
        return
      }
      const result = await call('EXECUTE', { account: state.account.account, plan: fresh }, (text) => setStatus(`${name} · ${text}`))
      state.holdingsReady = false
      state.sheet = {
        title: side === 'buy' ? `已买入 ${name}` : `已卖出 ${name}`,
        lines: fresh.preview?.lines || [],
        hashes: result.hashes || [],
        done: true,
      }
      paintSheet()
      await refreshAccount()
      await loadHoldings()
      setStatus(side === 'buy' ? `已买入 ${name}` : `已卖出 ${name}`)
    } catch (err) {
      fail(err)
      state.holdingsReady = false
      if (state.sheet) state.sheet.busyLabel = ''
    } finally {
      setBusy(false)
      if (state.sheet) paintSheet()
    }
  }

  function sellHeld() {
    if (state.busy) return
    if (!state.account) {
      fail(new Error('先连接 Agent 钱包'))
      return
    }
    const picked = heldRows()
    if (!picked.length) {
      fail(new Error('没有达到可卖数量的持仓'))
      return
    }
    const lines = picked.slice(0, 12).map((row) => {
      const bal = state.holdings.get(row.address) || 0n
      const pnl = sellPnl(row, bal)
      return [row.symbol || short(row.address), pnl ? `盈亏 ${pnl.text}` : `卖 ${state.sellPct}%`]
    })
    state.sheet = {
      title: `确认卖出 ${picked.length} 个`,
      lines,
      confirm: '确认卖出',
      onGo: () => sellAll(picked),
    }
    setStatus(`先点「确认卖出」，才会进钱包`)
    paintSheet()
  }

  async function sellAll(picked) {
    if (state.busy) return
    if (state.sheet) state.sheet.busyLabel = '卖出中…'
    setBusy(true)
    paintSheet()
    clearError()
    try {
      const result = await call('SELL_ALL', {
        account: state.account.account,
        slippage: state.slippage,
        pct: state.sellPct,
        rows: picked,
      }, (text) => setStatus(text))
      state.holdingsReady = false
      state.sheet = {
        title: '卖出完成',
        lines: [['笔数', String(result.hashes?.length || 0)]],
        hashes: result.hashes || [],
        done: true,
      }
      setStatus('完成')
      paintSheet()
      await refreshAccount()
      await loadHoldings()
    } catch (err) {
      fail(err)
      state.holdingsReady = false
      if (state.sheet) state.sheet.busyLabel = ''
    } finally {
      setBusy(false)
      if (state.sheet) paintSheet()
    }
  }

  launcher.addEventListener('click', () => {
    state.open = !state.open
    panel.hidden = !state.open
    launcher.setAttribute('aria-expanded', state.open ? 'true' : 'false')
  })

  conn.addEventListener('click', async () => {
    if (state.busy || loginBusy) return
    if (!state.account) {
      startScan()
      return
    }
    if (state.account.localOff) {
      restartLogin()
      return
    }
    setBusy(true)
    clearError()
    setStatus('正在读取 gang.fun 上的 Agent 钱包')
    try {
      state.account = await call('CONNECT')
      state.holdingsReady = false
      state.tab = 'holdings'
      paintAccount()
      paintTabs()
      setStatus('已连上 Agent 钱包')
      await loadHoldings()
      if (walletMismatch()) {
        setStatus('浏览器钱包不是持仓地址，正在切换到 Agent')
        const switched = await autoSwitch()
        if (!switched && !state.error) setStatus('浏览器钱包不是这个 Agent 地址。本机 Agent 登录后会自动改用它。')
      }
    } catch (err) {
      fail(err)
    } finally {
      setBusy(false)
    }
  })

  amountInput.addEventListener('input', () => {
    state.amount = amountInput.value.trim()
    scheduleSave()
    paintChips()
  })
  slipInput.addEventListener('input', () => {
    state.slippage = slipInput.value.trim()
    scheduleSave()
  })
  let lookupSeq = 0
  function findAddress(raw) {
    const key = String(raw || '').trim().toLowerCase()
    if (!isAddr(key)) {
      lookupSeq += 1
      state.looking = false
      return
    }
    if (state.tokens.some((row) => row.address === key)) {
      lookupSeq += 1
      state.looking = false
      return
    }
    const seq = ++lookupSeq
    state.looking = true
    clearError()
    setStatus('查询合约…')
    call('LOOKUP', { address: key }).then((row) => {
      if (seq !== lookupSeq) return
      state.looking = false
      const addr = String(row?.address || '').toLowerCase()
      if (!isAddr(addr)) throw new Error('索引里没有这个代币')
      if (!state.tokens.some((item) => item.address === addr)) state.tokens.unshift(row)
      clearError()
      setStatus('')
      paintList()
    }).catch((err) => {
      if (seq !== lookupSeq) return
      state.looking = false
      fail(err)
      paintList()
    })
  }
  function syncSearchClear() {
    searchClear.hidden = !search.value.trim()
  }
  search.addEventListener('input', () => {
    state.q = search.value
    syncSearchClear()
    if (state.error) clearError()
    findAddress(state.q)
    paintList()
  })
  searchClear.addEventListener('click', () => {
    search.value = ''
    state.q = ''
    syncSearchClear()
    findAddress('')
    search.focus()
    paintList()
  })
  search.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter') return
    findAddress(search.value)
    paintList()
  })

  paintChips()
  paintTabs()
  paintAccount()
  setStatus(state.status)

  call('BOOT').then(async (boot) => {
    state.tokens = boot?.tokens || []
    state.amount = boot?.prefs?.amount || state.amount
    if (OLD_BNB_AMOUNTS.has(state.amount)) state.amount = '10'
    const loadedSlip = Number(String(boot?.prefs?.slippage ?? '').trim())
    state.slippage = Number.isFinite(loadedSlip) && loadedSlip >= 0.1 && loadedSlip <= 50 ? String(loadedSlip) : '1'
    state.sellPct = Number(boot?.prefs?.sellPct) || state.sellPct
    amountInput.value = state.amount
    slipInput.value = state.slippage
    if (String(boot?.prefs?.slippage ?? '') !== state.slippage || (boot?.prefs?.amount && boot.prefs.amount !== state.amount)) scheduleSave()
    if (boot?.account?.account) {
      state.account = boot.account
      state.tab = 'holdings'
    }
    paintAccount()
    paintChips()
    paintTabs()
    clearError()
    setStatus(`${state.tokens.length} 个代币`)
    paintList()
    if (state.account) {
      await loadHoldings()
      if (walletMismatch()) await autoSwitch()
    }
  }).catch((err) => {
    fail(err)
    paintList()
  })
}
