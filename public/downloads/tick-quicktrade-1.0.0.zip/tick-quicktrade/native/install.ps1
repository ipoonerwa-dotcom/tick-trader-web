﻿# 客户在自己的 Windows 上运行一次。会安装 baw，并把签名程序注册给 Chrome。
$ErrorActionPreference = 'Stop'
$ExtId = 'jfokaabmchoeibmdmophekpbokgmgcle'
$HostName = 'com.ticktrader.quicktrade'
$Root = Split-Path -Parent $PSScriptRoot
$Src = Join-Path $PSScriptRoot 'host.js'

function Say([string]$Text) { Write-Host $Text }

function Find-Node {
  $cmd = Get-Command node -ErrorAction SilentlyContinue
  if ($cmd -and $cmd.Source) { return $cmd.Source }
  $candidates = @(
    "$env:ProgramFiles\nodejs\node.exe",
    "${env:ProgramFiles(x86)}\nodejs\node.exe"
  )
  foreach ($candidate in $candidates) {
    if (Test-Path -LiteralPath $candidate) { return $candidate }
  }
  return $null
}

function Find-Baw([string]$NodeDir) {
  foreach ($name in @('baw.cmd', 'baw.exe', 'baw')) {
    $beside = Join-Path $NodeDir $name
    if (Test-Path -LiteralPath $beside) { return $beside }
    $roaming = Join-Path $env:APPDATA "npm\$name"
    if (Test-Path -LiteralPath $roaming) { return $roaming }
  }
  $cmd = Get-Command baw -ErrorAction SilentlyContinue
  if ($cmd -and $cmd.Source) { return $cmd.Source }
  return $null
}

if (-not (Test-Path -LiteralPath $Src)) {
  Say "找不到 $Src。请在完整的扩展文件夹里运行。"
  exit 1
}

$dest = Join-Path $env:APPDATA 'TickQuickTrade'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$privateNode = Join-Path $dest 'node\node.exe'

function Install-PrivateNode {
  $arch = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
  $plat = if ($arch -eq 'Arm64') { 'win-arm64' } elseif ($arch -eq 'X64') { 'win-x64' } else { '' }
  if (-not $plat) {
    Say "这台电脑的芯片不受支持：$arch"
    exit 1
  }
  $version = 'v20.19.6'
  $name = "node-$version-$plat"
  $url = "https://nodejs.org/dist/$version/$name.zip"
  $sumUrl = "https://nodejs.org/dist/$version/SHASUMS256.txt"
  Say "这台电脑没有 Node。只下载到扩展自己的目录，不安装到系统里。"
  Say "目录：$(Join-Path $dest 'node')"
  $tmp = Join-Path ([System.IO.Path]::GetTempPath()) ("gang-node-" + [guid]::NewGuid().ToString('n'))
  New-Item -ItemType Directory -Force -Path $tmp | Out-Null
  $zip = Join-Path $tmp 'node.zip'
  $sums = Join-Path $tmp 'SHASUMS256.txt'
  try {
    Invoke-WebRequest -Uri $url -OutFile $zip
    Invoke-WebRequest -Uri $sumUrl -OutFile $sums
  } catch {
    Say "Node 下载失败。请检查网络后再双击一次。"
    exit 1
  }
  $expected = (Select-String -Path $sums -Pattern ("^([0-9a-f]{64})\s+" + [regex]::Escape("$name.zip") + "$")).Matches.Groups[1].Value
  $actual = (Get-FileHash -Algorithm SHA256 -Path $zip).Hash.ToLower()
  if (-not $expected -or $expected -ne $actual) {
    Say "Node 下载内容和官方校验不一致，已停止。系统目录没有被改动。"
    exit 1
  }
  Expand-Archive -Path $zip -DestinationPath $tmp -Force
  if (Test-Path -LiteralPath (Join-Path $dest 'node')) {
    Remove-Item -LiteralPath (Join-Path $dest 'node') -Recurse -Force
  }
  Move-Item -LiteralPath (Join-Path $tmp $name) -Destination (Join-Path $dest 'node')
  Remove-Item -LiteralPath $tmp -Recurse -Force
}

$node = Find-Node
if (-not $node -and (Test-Path -LiteralPath $privateNode)) { $node = $privateNode }
if (-not $node) {
  Install-PrivateNode
  $node = $privateNode
}
Say "Node：$node"
$nodeDir = Split-Path -Parent $node
$env:Path = "$nodeDir;$env:Path"

$dest = Join-Path $env:APPDATA 'TickQuickTrade'
New-Item -ItemType Directory -Force -Path $dest | Out-Null

$baw = Find-Baw $nodeDir
if (-not $baw) {
  $prefix = Join-Path $dest 'vendor'
  New-Item -ItemType Directory -Force -Path $prefix | Out-Null
  Say "这台电脑还没有 baw。只装进扩展自己的目录，不改系统 Node，也不动已经装好的全局包。"
  Say "目录：$prefix"
  $npm = Join-Path $nodeDir 'npm.cmd'
  if (-not (Test-Path -LiteralPath $npm)) { $npm = 'npm.cmd' }
  & $npm install --prefix $prefix '@binance/agentic-wallet'
  if ($LASTEXITCODE -ne 0) {
    Say "baw 没有装上。系统目录没有被改动。"
    exit 1
  }
  $baw = Join-Path $prefix 'node_modules\.bin\baw.cmd'
  if (-not (Test-Path -LiteralPath $baw)) {
    Say "baw 装完后仍找不到。系统目录没有被改动。"
    exit 1
  }
}
Say "baw：$baw"
Copy-Item -LiteralPath $Src -Destination (Join-Path $dest 'host.cjs') -Force
& $node --check (Join-Path $dest 'host.cjs')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$hostCmd = Join-Path $dest 'host.cmd'
$cmdText = @"
@echo off
set "PATH=$nodeDir;%PATH%"
set "BAW=$baw"
set "NODE_OPTIONS="
"$node" "%APPDATA%\TickQuickTrade\host.cjs"
"@
[System.IO.File]::WriteAllText($hostCmd, $cmdText.Replace("`n", "`r`n"), [System.Text.Encoding]::ASCII)

$jsonPath = Join-Path $dest "$HostName.json"
$hostJson = $hostCmd.Replace('\', '\\')
$json = @"
{
  "name": "$HostName",
  "description": "Tick Agent wallet signer",
  "path": "$hostJson",
  "type": "stdio",
  "allowed_origins": ["chrome-extension://$ExtId/"]
}
"@
[System.IO.File]::WriteAllText($jsonPath, $json.Replace("`n", "`r`n"), (New-Object System.Text.UTF8Encoding $false))

$regRoots = @(
  'HKCU:\Software\Google\Chrome\NativeMessagingHosts',
  'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts'
)
foreach ($root in $regRoots) {
  $key = Join-Path $root $HostName
  New-Item -Path $key -Force | Out-Null
  Set-ItemProperty -Path $key -Name '(default)' -Value $jsonPath
}

Say ""
Say "签名程序已经注册。"
Say "接下来："
Say "1. 完全退出 Chrome（只关窗口不够），再重新打开。"
Say "2. 打开 chrome://extensions，开发者模式，加载这个扩展文件夹。"
Say "   扩展 ID 必须是 $ExtId。"
Say "3. 打开 gang.fun 或 ticktraderai.io，点右下角「买卖」，再点面板右上角「扫码登录」，用这个 Agent 自己的币安 App 扫码。"
Say "   确认仍在币安 App 里点。这个 Agent 要开着开发者模式。"
