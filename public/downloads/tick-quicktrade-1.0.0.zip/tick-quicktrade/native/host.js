#!/usr/bin/env node
'use strict'

const os = require('os')
const path = require('path')
const { execFile } = require('child_process')
const { appendFileSync, existsSync, writeSync } = require('fs')

function supportDir() {
  if (process.env.GANG_HOST_DIR) return process.env.GANG_HOST_DIR
  if (process.platform === 'win32') {
    const base = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming')
    return path.join(base, 'TickQuickTrade')
  }
  if (process.platform === 'darwin') return path.join(os.homedir(), 'Library', 'Application Support', 'TickQuickTrade')
  return path.join(os.homedir(), '.config', 'TickQuickTrade')
}

const LOG = process.env.GANG_HOST_LOG || path.join(supportDir(), 'host.log')

function log(line) {
  try { appendFileSync(LOG, `${new Date().toISOString()} ${line}\n`) } catch { /* log is best effort */ }
}

function findBaw() {
  const fromEnv = process.env.BAW
  if (fromEnv && existsSync(fromEnv)) return fromEnv
  const names = process.platform === 'win32' ? ['baw.cmd', 'baw.exe', 'baw'] : ['baw']
  for (const dir of (process.env.PATH || '').split(path.delimiter)) {
    if (!dir) continue
    for (const name of names) {
      const candidate = path.join(dir, name)
      if (existsSync(candidate)) return candidate
    }
  }
  return ''
}

const BAW = findBaw()

function readMessage() {
  return new Promise((resolve, reject) => {
    let buf = Buffer.alloc(0)
    const onData = (chunk) => {
      buf = Buffer.concat([buf, chunk])
      if (buf.length < 4) return
      const len = buf.readUInt32LE(0)
      if (buf.length < 4 + len) return
      process.stdin.off('data', onData)
      try {
        resolve(JSON.parse(buf.subarray(4, 4 + len).toString('utf8')))
      } catch (err) {
        reject(err)
      }
    }
    process.stdin.on('data', onData)
    process.stdin.on('error', reject)
    process.stdin.resume()
  })
}

function writeMessage(obj) {
  const data = Buffer.from(JSON.stringify(obj))
  const head = Buffer.alloc(4)
  head.writeUInt32LE(data.length, 0)
  writeSync(1, Buffer.concat([head, data]))
}

function run(args, timeout = 180000) {
  return new Promise((resolve) => {
    if (!BAW) {
      resolve({ success: false, error: { message: '找不到 baw。请先安装 Binance Agentic Wallet 命令行。' } })
      return
    }
    execFile(BAW, [...args, '--json'], {
      maxBuffer: 8 << 20,
      timeout,
      windowsHide: true,
      shell: process.platform === 'win32',
    }, (err, stdout, stderr) => {
      const text = `${stdout || ''}${stderr || ''}`.trim()
      if (err?.killed) {
        resolve({ success: false, error: { message: '等太久了' } })
        return
      }
      try {
        resolve(JSON.parse(stdout))
      } catch {
        resolve({ success: false, error: { message: text || err?.message || 'baw 失败' } })
      }
    })
  })
}

function fail(error) {
  const message = error?.message || error?.name || (typeof error === 'string' ? error : 'Agent 钱包调用失败')
  return { ok: false, error: message }
}

function money(n) {
  const v = Number(n)
  if (!Number.isFinite(v)) return '$0'
  return `$${v.toLocaleString('en-US', { maximumFractionDigits: 2 })}`
}

function quotaText(q, need) {
  const size = need > 0 ? `这笔大约 ${money(need)}，已经超过了。` : '这笔如果超过剩余额度，就会被拒绝。'
  return `开发者模式今天还剩 ${money(q.left)}，上限 ${money(q.limit)}。${size}币安会直接拒绝，再点确认也一样。把金额改小，或到币安 App 调高开发者模式每日额度。北京时间今天早上 8 点恢复。`
}

async function devQuota() {
  const r = await run(['wallet', 'settings'])
  if (!r.success) return null
  const limit = Number(r.data?.devMode?.dailyLimit)
  const used = Number(r.data?.developerModeQuotaUsed)
  if (!Number.isFinite(limit) || !Number.isFinite(used)) return null
  return { limit, used, left: Math.max(0, limit - used) }
}

async function bnbUsd() {
  try {
    const res = await fetch('https://gang.fun/api/stats', { signal: AbortSignal.timeout(4000) })
    if (!res.ok) return 0
    const n = Number((await res.json())?.bnbUsd)
    return n > 0 ? n : 0
  } catch {
    return 0
  }
}

function wei(value) {
  const s = String(value || '0x0')
  return BigInt(s).toString()
}

async function status() {
  const r = await run(['wallet', 'status'])
  if (!r.success || r.data?.status !== 'CONNECTED') return { ok: false, error: '本机 Agent 钱包还没登录' }
  const addr = await run(['wallet', 'address'])
  if (!addr.success) return fail(addr.error)
  const row = (addr.data?.addresses || []).find((a) => a.binanceChainId === '56')
  if (!row?.address) return { ok: false, error: 'Agent 钱包没有 BSC 地址' }
  return { ok: true, address: row.address }
}

async function signin() {
  const live = await status()
  if (live.ok) return { ok: true, already: true, address: live.address }
  const r = await run(['auth', 'signin'])
  if (!r.success) return fail(r.error)
  const url = String(r.data?.urlForWeb || '')
  const qrCodeId = String(r.data?.qrCodeId || '')
  if (!/^https:\/\/app\.binance\.com\/uni-qr\/[A-Za-z0-9]+$/.test(url) || !/^[0-9a-f-]{36}$/i.test(qrCodeId)) {
    return { ok: false, error: '没有拿到登录二维码' }
  }
  return {
    ok: true,
    url,
    qrCodeId,
    pairingCode: String(r.data?.pairingCode || ''),
    expireAt: Number(r.data?.expireAt) || 0,
  }
}

async function verify(msg) {
  const qrCodeId = String(msg.qrCodeId || '')
  if (!/^[0-9a-f-]{36}$/i.test(qrCodeId)) return { ok: false, error: '登录编号不对' }
  const r = await run(['auth', 'verify', '--qrCodeId', qrCodeId], 240000)
  if (!r.success) return fail(r.error)
  const live = await status()
  if (!live.ok) return { ok: false, error: '扫码之后还是没有登录' }
  return { ok: true, address: live.address }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function txEnd(status) {
  const s = String(status || '').toLowerCase()
  if (['success', 'confirmed', 'partial_success'].includes(s)) return 'ok'
  if (['failed', 'fail', 'submit_fail', 'expire_fail', 'dropped', 'reverted', 'replaced', 'canceled', 'cancelled'].includes(s)) return 'fail'
  return ''
}

async function recentTxs() {
  const rows = []
  for (const type of ['pending', 'confirmed']) {
    const r = await run(['wallet', 'tx-history', '--type', type, '--binanceChainId', '56', '--size', '20'])
    for (const tx of r.data?.transactions || []) {
      const hash = String(tx?.txHash || tx?.txHashList?.[0]?.txHash || '')
      if (!/^0x[0-9a-f]{64}$/i.test(hash)) continue
      const time = Date.parse(tx.txTime) || 0
      rows.push({ hash: hash.toLowerCase(), time })
    }
  }
  return rows
}

/** App confirmation does not push back to us. Watch history until the new tx finishes. */
async function waitApp(seen) {
  let hash = ''
  const deadline = Date.now() + 180000
  while (Date.now() < deadline) {
    if (!hash) {
      const fresh = (await recentTxs()).filter((tx) => !seen.has(tx.hash))
      fresh.sort((a, b) => b.time - a.time)
      if (fresh[0]) hash = fresh[0].hash
    }
    if (hash) {
      const r = await run(['wallet', 'tx-history', '--tx', hash, '--binanceChainId', '56'])
      const end = txEnd(r.data?.status)
      if (end === 'ok') return { ok: true, hash }
      if (end === 'fail') return { ok: false, error: '你在币安 App 里取消了这笔，或者链上失败了。' }
    }
    await sleep(2000)
  }
  return { ok: false, error: '币安 App 里还没确认。打开 Agentic Wallet 点一下，再试一次。' }
}

async function send(msg) {
  const from = String(msg.from || '')
  const to = String(msg.to || '')
  const data = String(msg.data || '0x')
  if (!/^0x[0-9a-fA-F]{40}$/.test(from) || !/^0x[0-9a-fA-F]{40}$/.test(to)) {
    return { ok: false, error: '地址不对' }
  }
  if (!/^0x[0-9a-fA-F]*$/.test(data)) return { ok: false, error: '交易数据不对' }
  const valueWei = BigInt(wei(msg.value))
  const quoted = Number(msg.usd)
  let need = Number.isFinite(quoted) && quoted > 0 ? quoted : 0
  if (!(need > 0) && valueWei > 0n) need = Number(valueWei) / 1e18 * await bnbUsd()
  const quota = await devQuota()
  if (quota && need > quota.left + 0.5) {
    log(`quota block need=${need.toFixed(2)} left=${quota.left.toFixed(2)}`)
    return { ok: false, error: quotaText(quota, need) }
  }
  const args = [
    'contract-call', 'preview',
    '--binanceChainId', '56',
    '--from', from,
    '--to', to,
    '--value', wei(msg.value),
    '--inputData', data,
  ]
  for (let attempt = 0; attempt < 2; attempt++) {
    const preview = await run(args)
    if (!preview.success) return fail(preview.error)
    const requestId = preview.data?.requestId
    if (!requestId) return { ok: false, error: 'Agent 钱包没有返回预览编号' }
    const seen = new Set((await recentTxs()).map((tx) => tx.hash))
    const done = await run(['contract-call', 'execute', '--requestId', requestId])
    if (done.success) {
      const d = done.data || {}
      if (d.status === 'PENDING_CONFIRMATION') {
        log('wait app confirmation')
        const waited = await waitApp(seen)
        log(`app wait ${waited.ok ? 'ok' : 'stop'}`)
        return waited
      }
      if (!d.txHash) return { ok: false, error: `Agent 钱包没有发出交易（${d.status || '未知状态'}）` }
      return { ok: true, hash: d.txHash }
    }
    const message = fail(done.error).error
    log(`execute fail ${done.error?.code || ''} ${String(message).slice(0, 160)}`)
    if (/risk status has changed/i.test(message)) {
      const left = quota || await devQuota()
      const over = left && need > left.left + 0.5
      const unknownAndTight = left && !(need > 0) && left.left < 12
      if (over || unknownAndTight) {
        return { ok: false, error: quotaText(left, need) }
      }
      if (attempt === 0) {
        log('risk changed, preview again')
        continue
      }
      return { ok: false, error: '币安风控结果和预览对不上，再点一次也过不了。先看币安 App 里有没有还没确认的交易。' }
    }
    return { ok: false, error: message }
  }
  return { ok: false, error: '币安拒绝了这笔签名。' }
}

async function main() {
  log('started')
  if (!BAW) {
    writeMessage({ ok: false, error: '找不到 baw。请先安装 Binance Agentic Wallet 命令行。' })
    return
  }
  const msg = await readMessage()
  log(`cmd ${msg && msg.cmd}`)
  if (msg.cmd === 'status') writeMessage(await status())
  else if (msg.cmd === 'send') writeMessage(await send(msg))
  else if (msg.cmd === 'signin') writeMessage(await signin())
  else if (msg.cmd === 'verify') writeMessage(await verify(msg))
  else writeMessage({ ok: false, error: '未知操作' })
  log('replied')
}

main().catch((err) => {
  writeMessage({ ok: false, error: err.message || 'Agent 钱包调用失败' })
})
