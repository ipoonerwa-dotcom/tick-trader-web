#!/bin/bash
# 客户在自己的 Mac 上运行一次。会安装 baw，并把签名程序注册给 Chrome。
set -euo pipefail

EXT_ID="jfokaabmchoeibmdmophekpbokgmgcle"
HOST_NAME="com.ticktrader.quicktrade"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/native/host.js"

say() { printf '%s\n' "$*"; }

load_node_env() {
  export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
  if [ -s "$NVM_DIR/nvm.sh" ]; then
    # shellcheck disable=SC1091
    . "$NVM_DIR/nvm.sh"
  fi
  if [ -d "$HOME/.volta/bin" ]; then
    export PATH="$HOME/.volta/bin:$PATH"
  fi
}

list_nodes() {
  if [ -d "$HOME/.nvm/versions/node" ]; then
    find "$HOME/.nvm/versions/node" -mindepth 3 -maxdepth 3 -type f -name node 2>/dev/null | sort -Vr
  fi
  if [ -x "$HOME/.volta/bin/node" ]; then
    echo "$HOME/.volta/bin/node"
  fi
  if [ -x /opt/homebrew/bin/node ]; then
    echo /opt/homebrew/bin/node
  fi
  if command -v node >/dev/null 2>&1; then
    command -v node
  fi
  if [ -x /usr/local/bin/node ]; then
    echo /usr/local/bin/node
  fi
}

find_pair() {
  local node="" baw="" seen="|"
  while IFS= read -r node; do
    [ -n "$node" ] && [ -x "$node" ] || continue
    case "$seen" in
      *"|$node|"*) continue ;;
    esac
    seen="${seen}${node}|"
    baw="$(dirname "$node")/baw"
    if [ -x "$baw" ]; then
      NODE="$node"
      BAW="$baw"
      return 0
    fi
    if [ -z "${FALLBACK_NODE:-}" ]; then
      FALLBACK_NODE="$node"
    fi
  done
  return 1
}

write_manifest() {
  local manifest="$1"
  local host_bin="$2"
  mkdir -p "$(dirname "$manifest")"
  "$NODE" - "$manifest" "$host_bin" "$EXT_ID" "$HOST_NAME" << 'JS'
const fs = require('fs')
const path = require('path')
const [manifest, host, ext, name] = process.argv.slice(2)
if (!manifest || manifest === '-' || !host || !ext || !name) {
  console.error('注册参数不对，已停止，避免写到错误文件。')
  process.exit(1)
}
fs.mkdirSync(path.dirname(manifest), { recursive: true })
fs.writeFileSync(manifest, JSON.stringify({
  name,
  description: 'Tick Agent wallet signer',
  path: host,
  type: 'stdio',
  allowed_origins: [`chrome-extension://${ext}/`],
}, null, 2) + '\n')
JS
}

download_private_node() {
  local version="v20.19.6" plat name url tmp expected actual
  case "$(uname -m)" in
    arm64) plat="darwin-arm64" ;;
    x86_64) plat="darwin-x64" ;;
    *)
      say "这台电脑的芯片不受支持：$(uname -m)"
      exit 1
      ;;
  esac
  name="node-${version}-${plat}"
  url="https://nodejs.org/dist/${version}/${name}.tar.gz"
  say "这台电脑没有 Node。只下载到扩展自己的目录，不安装到系统里。"
  say "目录：$DEST/node"
  tmp="$(mktemp -d)"
  if ! curl -fsSL "$url" -o "$tmp/node.tar.gz"; then
    rm -rf "$tmp"
    say "Node 下载失败。请检查网络后再双击一次。"
    exit 1
  fi
  if ! curl -fsSL "https://nodejs.org/dist/${version}/SHASUMS256.txt" -o "$tmp/SHASUMS256.txt"; then
    rm -rf "$tmp"
    say "没法核对 Node 的校验和。请检查网络后再双击一次。"
    exit 1
  fi
  expected="$(awk -v f="${name}.tar.gz" '$2 == f { print $1 }' "$tmp/SHASUMS256.txt")"
  actual="$(shasum -a 256 "$tmp/node.tar.gz" | awk '{ print $1 }')"
  if [ -z "$expected" ] || [ "$expected" != "$actual" ]; then
    rm -rf "$tmp"
    say "Node 下载内容和官方校验不一致，已停止。系统目录没有被改动。"
    exit 1
  fi
  tar -xzf "$tmp/node.tar.gz" -C "$tmp"
  rm -rf "$DEST/node"
  mv "$tmp/$name" "$DEST/node"
  rm -rf "$tmp"
  xattr -dr com.apple.quarantine "$DEST/node" 2>/dev/null || true
  NODE="$DEST/node/bin/node"
}

install_private_baw() {
  local prefix="$DEST/vendor"
  NODE_DIR="$(dirname "$NODE")"
  export PATH="$NODE_DIR:/usr/bin:/bin"
  NPM="$NODE_DIR/npm"
  if [ ! -e "$NPM" ]; then
    say "找到了 Node，但没有 npm，没法安装 baw。系统目录没有被改动。"
    exit 1
  fi
  mkdir -p "$prefix"
  say "baw 只装进扩展自己的目录，不改系统 Node，也不动已经装好的全局包。"
  say "目录：$prefix"
  if ! "$NPM" install --prefix "$prefix" @binance/agentic-wallet; then
    say "baw 没有装上。系统目录没有被改动。"
    exit 1
  fi
  BAW="$prefix/node_modules/.bin/baw"
  if [ ! -x "$BAW" ]; then
    say "baw 装完后仍找不到。系统目录没有被改动。"
    exit 1
  fi
}

if [ "$(uname -s)" != "Darwin" ]; then
  say "这个脚本只给 Mac。Windows 请双击「install-windows.bat」。"
  exit 1
fi

if [ ! -f "$SRC" ]; then
  say "找不到 $SRC。请在完整的扩展文件夹里运行。"
  exit 1
fi

load_node_env

DEST="$HOME/Library/Application Support/TickQuickTrade"
mkdir -p "$DEST"
PRIVATE_NODE="$DEST/node/bin/node"
PRIVATE_BAW="$DEST/vendor/node_modules/.bin/baw"

FALLBACK_NODE=""
NODE=""
BAW=""
if [ -x "$PRIVATE_NODE" ] && [ -x "$PRIVATE_BAW" ]; then
  NODE="$PRIVATE_NODE"
  BAW="$PRIVATE_BAW"
elif find_pair < <(list_nodes); then
  :
else
  if [ -n "$FALLBACK_NODE" ]; then
    NODE="$FALLBACK_NODE"
  elif [ -x "$PRIVATE_NODE" ]; then
    NODE="$PRIVATE_NODE"
  else
    download_private_node
  fi
  install_private_baw
fi
NODE_DIR="$(dirname "$NODE")"
say "Node：$NODE"
say "baw：$BAW"

cp "$SRC" "$DEST/host.cjs"
"$NODE" --check "$DEST/host.cjs"

cat > "$DEST/host" << EOF
#!/bin/bash
export PATH="$NODE_DIR:/usr/bin:/bin"
export HOME="$HOME"
export BAW="$BAW"
unset NODE_OPTIONS
DIR="\$HOME/Library/Application Support/TickQuickTrade"
mkdir -p "\$DIR"
echo "bash \$(date)" >> "\$DIR/host.log"
exec "$NODE" "\$DIR/host.cjs"
EOF
chmod +x "$DEST/host"
xattr -d com.apple.quarantine "$DEST/host" 2>/dev/null || true

SUPPORT="$HOME/Library/Application Support"
write_manifest "$SUPPORT/Google/Chrome/NativeMessagingHosts/$HOST_NAME.json" "$DEST/host"
for browser in "Microsoft Edge" "BraveSoftware/Brave-Browser" "Chromium" "Google/Chrome Canary"; do
  if [ -d "$SUPPORT/$browser" ]; then
    write_manifest "$SUPPORT/$browser/NativeMessagingHosts/$HOST_NAME.json" "$DEST/host"
  fi
done

say ""
say "签名程序已经注册。"
say "接下来："
say "1. 完全退出 Chrome（只关窗口不够），再重新打开。"
say "2. 打开 chrome://extensions，开发者模式，加载这个扩展文件夹。"
say "   扩展 ID 必须是 ${EXT_ID}。"
say "3. 打开 gang.fun 或 ticktraderai.io，点右下角「买卖」，再点面板右上角「扫码登录」，用这个 Agent 自己的币安 App 扫码。"
say "   确认仍在币安 App 里点。这个 Agent 要开着开发者模式。"
