// Content scripts cannot use static imports, so the panel module (and its lib/ imports) loads on demand.
// They are listed in web_accessible_resources for that reason.
if (!document.getElementById('gang-quick-host')) {
  const host = document.createElement('div')
  host.id = 'gang-quick-host'
  host.style.cssText = 'position:fixed;z-index:2147483646;top:0;right:0;bottom:0;left:0;width:100%;height:auto;pointer-events:none;overflow:visible;'
  const shadow = host.attachShadow({ mode: 'open' })
  const link = document.createElement('link')
  link.rel = 'stylesheet'
  link.href = chrome.runtime.getURL('content.css?v=13')
  const app = document.createElement('div')
  shadow.append(link, app)
  document.documentElement.append(host)
  import(chrome.runtime.getURL('ui.js'))
    .then(({ mount }) => mount(app, { variant: 'dock' }))
    .catch((err) => console.error('Tick 快速买卖 did not load', err))
}
