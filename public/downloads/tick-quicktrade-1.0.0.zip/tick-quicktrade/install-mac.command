#!/bin/bash
cd "$(dirname "$0")"
bash native/install.sh
status=$?
echo
if [ "$status" -eq 0 ]; then
  read -r -p "安装完成。按回车键关闭窗口…" _
else
  read -r -p "安装没有完成。按回车键关闭窗口…" _
fi
exit "$status"
