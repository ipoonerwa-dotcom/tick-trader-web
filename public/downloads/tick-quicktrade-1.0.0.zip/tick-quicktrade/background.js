import { GANG_RE, SITE_RE } from './lib/constants.js'
import { bookRows, loadMarket, lookupToken, walletRows } from './lib/market.js'
import { humanError, isAddr, parseSlippage } from './lib/format.js'
import { rpc } from './lib/rpc.js'
import { assertSteps, capSpends, holdingsOf, planBuy, planSell, readAccount } from './lib/trade.js'

const KEY = 'gq'
const DEFAULTS = { amount: '10', slippage: '1', sellPct: 100 }
const PANEL_URL = chrome.runtime.getURL('popup.html')

async function panelBox() {
  const wins = await chrome.windows.getAll({ windowTypes: ['normal'] })
  const current = wins.find((win) => win.focused) || wins[0] || {}
  const width = 860
  const height = Math.max(960, (current.height || 1100) - 12)
  const left = Math.max(0, (current.left || 0) + (current.width || 1440) - width - 12)
  const top = Math.max(0, current.top || 0)
  return { width, height, left, top }
}

async function findPanel() {
  const wins = await chrome.windows.getAll({ populate: true, windowTypes: ['popup'] })
  return wins.find((win) => (win.tabs || []).some((tab) => String(tab.url || '').startsWith(PANEL_URL))) || null
}

async function openPanel() {
  const box = await panelBox()
  const existing = await findPanel()
  if (existing?.id != null) {
    try {
      await chrome.windows.update(existing.id, { focused: true, state: 'normal', ...box })
    } catch {
      await chrome.windows.update(existing.id, { focused: true, ...box })
    }
    return
  }
  const created = await chrome.windows.create({ url: PANEL_URL, type: 'popup', focused: true, ...box })
  if (created?.id != null && created.height && created.height < box.height - 80) {
    await chrome.windows.update(created.id, box)
  }
}

chrome.action.onClicked.addListener(() => {
  openPanel().catch(() => {})
})

let marketCache = { at: 0, tokens: null }

function slippageOrDefault(value) {
  const n = Number(String(value ?? '').trim())
  if (!Number.isFinite(n) || n < 0.1 || n > 50) return DEFAULTS.slippage
  return String(n)
}

async function prefs() {
  const bag = await chrome.storage.local.get(KEY)
  const stored = bag[KEY] || {}
  const next = { ...DEFAULTS, ...stored, slippage: slippageOrDefault(stored.slippage ?? DEFAULTS.slippage) }
  if (next.slippage !== stored.slippage) {
    await chrome.storage.local.set({ [KEY]: { ...stored, slippage: next.slippage } })
  }
  return next
}

async function savePrefs(patch) {
  const clean = { ...patch }
  if ('slippage' in clean) clean.slippage = slippageOrDefault(clean.slippage)
  const next = { ...(await prefs()), ...clean }
  await chrome.storage.local.set({ [KEY]: next })
  return next
}

async function market(force) {
  if (!force && marketCache.tokens && Date.now() - marketCache.at < 20_000) return marketCache.tokens
  const tokens = await loadMarket()
  marketCache = { at: Date.now(), tokens }
  return tokens
}

function waitTab(tabId) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(onUpdated)
      reject(new Error('打开 gang.fun 超时'))
    }, 20_000)
    const onUpdated = (id, info) => {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer)
        chrome.tabs.onUpdated.removeListener(onUpdated)
        resolve()
      }
    }
    chrome.tabs.onUpdated.addListener(onUpdated)
  })
}

function siteOk(tab, re) {
  return Boolean(tab?.id && tab.url && re.test(tab.url))
}

/** An open tab on one of our sites (any of them by default; GANG_RE for gang.fun-only work). */
async function siteTab(re = SITE_RE) {
  const tabs = await chrome.tabs.query({})
  return tabs.find((tab) => tab.active && siteOk(tab, re)) || tabs.find((tab) => siteOk(tab, re)) || null
}

async function findTab(re = SITE_RE) {
  const found = await siteTab(re)
  if (found) return found
  const created = await chrome.tabs.create({ url: 'https://gang.fun/', active: true })
  await waitTab(created.id)
  return created
}

/** Runs on gang.fun. Starts the same Binance App QR the site header used to show. */
function pageAgentSignin() {
  const read = (path, opts = {}) => fetch(`/api/agent-wallet${path}`, {
    method: opts.method || 'GET',
    credentials: 'same-origin',
    headers: {
      Accept: 'application/json',
      ...(opts.csrf ? { 'X-CSRF-Token': opts.csrf } : {}),
    },
  }).then(async (res) => {
    const json = await res.json().catch(() => ({}))
    if (!res.ok) throw new Error(json?.message || `登录接口 ${res.status}`)
    return json?.data ?? json
  })
  return read('/session').then(async (session) => {
    const live = session?.session || {}
    const have = String(live.address || '')
    if (live.status === 'connected' && /^0x[0-9a-fA-F]{40}$/.test(have)) {
      return { already: true, address: have, handle: live.handle || live.aiDomain || '' }
    }
    const csrf = session?.csrf_token
    if (!csrf) throw new Error('没有拿到登录凭证')
    const data = await read('/signins', { method: 'POST', csrf })
    const url = String(data.signin_url || data.signinUrl || '')
    const uid = String(data.uid || '')
    if (!url.startsWith('https://') || !uid) throw new Error('没有拿到登录二维码')
    return {
      url,
      uid,
      pairingCode: String(data.pairing_code || data.pairingCode || ''),
      expireAt: Number(data.expire_at || data.expireAt) || 0,
    }
  }).catch((err) => ({ error: err?.message || '登录二维码没有出来' }))
}

/** Runs on gang.fun. One poll of a sign-in started by pageAgentSignin. */
function pageAgentPoll(uid) {
  return fetch(`/api/agent-wallet/signins/${encodeURIComponent(uid)}`, {
    credentials: 'same-origin',
    headers: { Accept: 'application/json' },
  }).then(async (res) => {
    const json = await res.json().catch(() => ({}))
    if (!res.ok) return { error: json?.message || `登录接口 ${res.status}` }
    const data = json?.data ?? json
    const session = data.session || {}
    return {
      status: String(data.status || session.status || ''),
      address: String(data.address || session.address || ''),
      handle: String(data.handle || session.handle || data.aiDomain || session.aiDomain || ''),
      expireAt: Number(data.expire_at || data.expireAt) || 0,
    }
  }).catch((err) => ({ error: err?.message || '查询登录状态失败' }))
}

/** Runs on gang.fun. Reads the Agent wallet session cookie, not the browser extension account. */
function pageSession() {
  return fetch('/api/agent-wallet/session', {
    credentials: 'same-origin',
    headers: { Accept: 'application/json' },
  }).then(async (res) => {
    const json = await res.json().catch(() => ({}))
    const data = json?.data ?? json
    const session = data?.session || {}
    const address = String(session.address || '')
    if (session.status === 'connected' && /^0x[0-9a-fA-F]{40}$/.test(address)) {
      return {
        address,
        handle: session.handle || session.aiDomain || '',
        status: 'connected',
      }
    }
    return { address: null, status: session.status || 'idle' }
  }).catch((err) => ({ address: null, status: 'error', error: err?.message || '读取 Agent 会话失败' }))
}

async function readAgentSession() {
  const tab = await siteTab(GANG_RE)
  if (!tab) return { address: null, status: 'no-tab' }
  try {
    const [injected] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: pageSession,
    })
    return injected?.result || { address: null, status: 'idle' }
  } catch (err) {
    return { address: null, status: 'error', error: err?.message || '读取 Agent 会话失败' }
  }
}

async function signerOnPage() {
  const tab = await siteTab()
  if (!tab?.id) return ''
  try {
    const out = await inject(tab.id, { mode: 'peek' })
    return isAddr(out?.account) ? out.account : ''
  } catch {
    return ''
  }
}

/** Whoever is logged in on this browser. Never falls back to a built-in handle. */
async function chooseAccount(session, stored) {
  const signer = await signerOnPage()
  let chosen = null
  if (isAddr(session?.address)) {
    chosen = { address: session.address, handle: session.handle || '', agent: true, via: '' }
  } else if (stored?.via === 'baw' && isAddr(stored.account)) {
    chosen = { address: stored.account, handle: stored.handle || '', agent: true, via: 'baw' }
  } else if (isAddr(signer)) {
    chosen = { address: signer, handle: '', agent: false, via: '' }
  }
  if (!chosen) return null
  const account = await readAccount(chosen.address).catch(() => ({ account: chosen.address, bnb: '—', isAgent: false }))
  account.handle = chosen.handle || ''
  account.agent = Boolean(chosen.agent || account.isAgent)
  account.signer = signer
  account.via = chosen.via || ''
  return account
}

async function focus(tab) {
  try { await chrome.tabs.update(tab.id, { active: true }) } catch { /* tab closed */ }
}

/**
 * Runs in the gang.fun page (MAIN world). Must not close over extension imports:
 * Chrome serializes this function alone.
 */
function pageRun(job) {
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

  function isBinance(provider) {
    return Boolean(provider && (
      provider.isBinance || provider.isBinanceWallet || provider.isBinanceW3W
      || provider.isBinanceWeb3Wallet || provider.isBn || provider.bnb
    ))
  }

  function syncPick() {
    const eth = window.ethereum
    const list = Array.isArray(eth?.providers) && eth.providers.length ? eth.providers : (eth ? [eth] : [])
    const flagged = list.find(isBinance)
    if (flagged) return flagged
    const w3w = window.binancew3w?.ethereum || window.binancew3w
    if (w3w && typeof w3w.request === 'function') return w3w
    if (window.BinanceChain?.request) return window.BinanceChain
    if (list.length === 1) {
      const only = list[0]
      const rejected = only.isMetaMask || only.isOkxWallet || only.isOKXWallet || only.isCoinbaseWallet || only.isPhantom
      if (!rejected) return only
    }
    return null
  }

  async function pick() {
    const direct = syncPick()
    if (direct) return direct
    const found = []
    const onAnnounce = (event) => {
      if (event.detail?.provider) found.push(event.detail)
    }
    window.addEventListener('eip6963:announceProvider', onAnnounce)
    window.dispatchEvent(new Event('eip6963:requestProvider'))
    await sleep(80)
    window.removeEventListener('eip6963:announceProvider', onAnnounce)
    for (const { info, provider } of found) {
      const rdns = String(info?.rdns || '').toLowerCase()
      const name = String(info?.name || '')
      if (rdns.includes('binance') || /binance/i.test(name) || isBinance(provider)) return provider
    }
    return null
  }

  async function ensureChain(provider) {
    const chainId = await provider.request({ method: 'eth_chainId' })
    if (parseInt(chainId, 16) === 56) return
    try {
      await provider.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: '0x38' }] })
    } catch (err) {
      const code = err?.code ?? err?.data?.code
      if (code !== 4902) throw err
      await provider.request({
        method: 'wallet_addEthereumChain',
        params: [{
          chainId: '0x38',
          chainName: 'BNB Smart Chain',
          nativeCurrency: { name: 'BNB', symbol: 'BNB', decimals: 18 },
          rpcUrls: ['https://bsc-dataseed.binance.org'],
          blockExplorerUrls: ['https://bscscan.com'],
        }],
      })
    }
  }

  async function waitReceipt(provider, hash) {
    for (let i = 0; i < 40; i++) {
      const rec = await provider.request({ method: 'eth_getTransactionReceipt', params: [hash] })
      if (rec) return rec
      await sleep(1500)
    }
    return null
  }

  return (async () => {
    const hashes = []
    try {
      const provider = await pick()
      if (!provider) {
        return { error: '没有找到 Binance Wallet。请安装 Binance Wallet，并允许它在这个标签页注入。' }
      }
      if (job.mode === 'peek') {
        const accounts = await provider.request({ method: 'eth_accounts' }).catch(() => [])
        return { account: accounts?.[0] || '' }
      }
      await ensureChain(provider)
      let accounts = await provider.request({ method: 'eth_accounts' })
      if (!accounts?.length) accounts = await provider.request({ method: 'eth_requestAccounts' })
      const want = String(job.from || '').toLowerCase()
      let from = (accounts || []).find((a) => String(a).toLowerCase() === want) || accounts?.[0]
      if (!from) return { error: '钱包没有返回地址。请先在 gang.fun 用 Binance Wallet 点一次连接。' }
      if (job.mode === 'connect') return { account: from }
      if (want && from.toLowerCase() !== want) {
        return { error: `持仓在 Agent 钱包 ${job.from}，浏览器钱包是 ${from}。点顶栏「切换到 Agent」，确认会出现在币安 App。` }
      }
      for (const step of job.steps || []) {
        const hash = await provider.request({
          method: 'eth_sendTransaction',
          params: [{ from, to: step.to, data: step.data, value: step.value || '0x0' }],
        })
        hashes.push(hash)
        const rec = await waitReceipt(provider, hash)
        if (!rec) return { error: `等了太久还没上链：${hash}`, hashes }
        if (rec.status !== '0x1') return { error: `交易失败 ${hash}`, hashes }
      }
      return { hashes }
    } catch (err) {
      const message = err?.message || String(err)
      if (/reject|denied|cancel/i.test(message)) return { error: '你在钱包里取消了', hashes }
      return { error: message, hashes }
    }
  })()
}

async function inject(tabId, job) {
  const [injected] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: pageRun,
    args: [job],
  })
  return injected?.result
}

async function withKeepalive(fn) {
  const timer = setInterval(() => { chrome.runtime.getPlatformInfo(() => {}) }, 10_000)
  try { return await fn() } finally { clearInterval(timer) }
}

const HOST = 'com.ticktrader.quicktrade'

function nativeCall(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendNativeMessage(HOST, message, (resp) => {
      const err = chrome.runtime.lastError
      if (err) reject(new Error(err.message))
      else resolve(resp || { ok: false, error: 'Agent 钱包没有返回' })
    })
  })
}

async function waitChain(hash) {
  for (let i = 0; i < 40; i++) {
    const rec = await rpc('eth_getTransactionReceipt', [hash]).catch(() => null)
    if (rec) return rec
    await new Promise((resolve) => setTimeout(resolve, 1500))
  }
  return null
}

async function sendViaAgent(steps, from, progress, usd) {
  const hashes = []
  for (let i = 0; i < steps.length; i++) {
    const step = steps[i]
    progress(step.label ? `${step.label}：请在币安 App 确认，点完会自动继续` : '请在币安 App 确认，点完会自动继续')
    const out = await nativeCall({
      cmd: 'send',
      from,
      to: step.to,
      data: step.data,
      value: step.value || '0x0',
      usd: Number(usd) || 0,
    })
    if (!out?.ok) throw new Error(out?.error || 'Agent 签名失败')
    if (out.pending) throw new Error('请打开币安 App，在 Agentic Wallet 里确认这笔交易')
    hashes.push(out.hash)
    const rec = await waitChain(out.hash)
    if (!rec) throw new Error(`等了太久还没上链：${out.hash}`)
    if (rec.status !== '0x1') throw new Error(`交易失败 ${out.hash}`)
  }
  return hashes
}

async function sendSteps(steps, from, token, quote, progress, usd) {
  assertSteps(steps, token, quote)
  const stored = await prefs()
  const viaAgent = async () => {
    progress('浏览器钱包不是持仓地址，改用 Agent 钱包')
    const live = await nativeCall({ cmd: 'status' }).catch((err) => ({ ok: false, error: err?.message }))
    if (!live?.ok) throw new Error(live?.error || '本机 Agent 钱包还没登录')
    if (String(live.address).toLowerCase() !== String(from).toLowerCase()) {
      throw new Error(`本机登录的 Agent 是 ${live.address}，持仓在 ${from}`)
    }
    await savePrefs({ account: from, handle: stored.handle || '', agent: true, via: 'baw' })
    return withKeepalive(() => sendViaAgent(steps, from, progress, usd))
  }
  if (stored.via === 'baw') {
    return withKeepalive(() => sendViaAgent(steps, from, progress, usd))
  }
  const tab = await findTab()
  const peek = await inject(tab.id, { mode: 'peek' }).catch(() => null)
  const signer = String(peek?.account || '')
  if (isAddr(from) && isAddr(signer) && signer.toLowerCase() !== String(from).toLowerCase()) {
    return viaAgent()
  }
  await focus(tab)
  progress('请在 Binance Wallet 确认')
  const out = await withKeepalive(() => inject(tab.id, { mode: 'send', from, steps }))
  if (!out) throw new Error('页面没有返回结果')
  if (out.error && /持仓在 Agent 钱包/.test(out.error)) return viaAgent()
  if (out.error) {
    const done = out.hashes?.length ? `（前面 ${out.hashes.length} 笔已经发出）` : ''
    throw new Error(`${out.error}${done}`)
  }
  return out.hashes || []
}

function tradeInput(payload) {
  const row = payload?.row || {}
  const token = String(row.address || payload.token || '').trim()
  if (!isAddr(token)) throw new Error('缺少代币地址')
  return {
    token,
    from: payload.account,
    slippageBps: parseSlippage(payload.slippage),
    hint: row.v2Launchpad || '',
    pair: row.pair || '',
    symbol: row.symbol || '',
    quoteSymbol: row.quoteSymbol || 'BNB',
    taxed: Boolean(row.taxed),
    track: row.track || '',
  }
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'gq') return
  port.onMessage.addListener((msg) => {
    const progress = (text) => {
      try { port.postMessage({ id: msg.id, progress: text }) } catch { /* popup closed */ }
    }
    dispatch(msg, progress)
      .then((result) => port.postMessage({ id: msg.id, result }))
      .catch((err) => {
        try { port.postMessage({ id: msg.id, error: humanError(err) }) } catch { /* closed */ }
      })
  })
})

async function dispatch(msg, progress) {
  const payload = msg.payload || {}
  switch (msg.action) {
    case 'BOOT': {
      const [stored, tokens, session] = await Promise.all([prefs(), market(false), readAgentSession()])
      const account = await chooseAccount(session, stored)
      if (account?.via === 'baw' && account.account) {
        const live = await nativeCall({ cmd: 'status' }).catch(() => null)
        if (live?.ok && String(live.address).toLowerCase() === account.account.toLowerCase()) {
          account.signer = account.account
          account.localOff = false
        } else {
          account.localOff = true
        }
      }
      if (account?.account) {
        await savePrefs({
          account: account.account,
          handle: account.handle || '',
          agent: Boolean(account.agent),
          via: account.via || '',
        })
      }
      return {
        tokens,
        account,
        prefs: { amount: stored.amount, slippage: stored.slippage, sellPct: stored.sellPct },
      }
    }
    case 'REFRESH':
      return { tokens: await market(true) }
    case 'SAVE_PREFS':
      return savePrefs({
        amount: payload.amount,
        slippage: payload.slippage,
        sellPct: payload.sellPct,
      })
    case 'LOOKUP':
      return lookupToken(payload.address)
    case 'CAP_LEFT': {
      if (!isAddr(payload.account)) return { rows: [] }
      const rows = await capSpends(payload.account, payload.tokens || [])
      return { rows }
    }
    case 'SCAN': {
      const tab = await findTab(GANG_RE)
      const [injected] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: pageAgentSignin,
      })
      const out = injected?.result
      if (!out || out.error) throw new Error(out?.error || '登录二维码没有出来')
      return out
    }
    case 'SCAN_WAIT': {
      const uid = String(payload.uid || '')
      if (!uid) throw new Error('登录编号不对')
      const started = Date.now()
      return withKeepalive(async () => {
        while (Date.now() - started < 300000) {
          const tab = await siteTab(GANG_RE)
          if (!tab?.id) throw new Error('gang.fun 页面关了，二维码没法继续等')
          const [injected] = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: 'MAIN',
            func: pageAgentPoll,
            args: [uid],
          })
          const polled = injected?.result || {}
          if (polled.error) throw new Error(polled.error)
          const expireAt = Number(polled.expireAt) || 0
          if (polled.status === 'expired' || polled.status === 'cancelled' || polled.status === 'failed' || (expireAt > 0 && Date.now() > expireAt)) {
            throw new Error('二维码过期了。点「换一个二维码」再扫一次。')
          }
          if (polled.status === 'connected' && isAddr(polled.address)) {
            return { address: polled.address, handle: polled.handle || '' }
          }
          await new Promise((resolve) => setTimeout(resolve, 2000))
        }
        throw new Error('二维码过期了。点「换一个二维码」再扫一次。')
      })
    }
    case 'USE_BAW': {
      const live = await nativeCall({ cmd: 'status' })
      if (!live?.ok || !isAddr(live.address)) throw new Error(live?.error || '本机 Agent 钱包还没登录')
      const account = await readAccount(live.address)
      account.handle = ''
      account.agent = true
      account.signer = account.account
      account.via = 'baw'
      await savePrefs({ account: account.account, handle: '', agent: true, via: 'baw' })
      return account
    }
    case 'LOGIN': {
      const out = await withKeepalive(() => nativeCall({ cmd: 'signin' }))
      if (!out?.ok) throw new Error(out?.error || '登录二维码没有出来')
      return out
    }
    case 'LOGIN_WAIT': {
      const out = await withKeepalive(() => nativeCall({ cmd: 'verify', qrCodeId: payload.qrCodeId }))
      if (!out?.ok) throw new Error(out?.error || '登录没有完成')
      return out
    }
    case 'SWITCH': {
      if (!isAddr(payload.account)) throw new Error('还没有 Agent 钱包地址')
      const live = await nativeCall({ cmd: 'status' })
      if (!live?.ok) throw new Error(live?.error || '本机 Agent 钱包还没登录')
      if (String(live.address).toLowerCase() !== String(payload.account).toLowerCase()) {
        throw new Error(`本机登录的 Agent 是 ${live.address}，持仓在 ${payload.account}`)
      }
      const stored = await prefs()
      const account = await readAccount(live.address)
      account.handle = stored.handle || ''
      account.agent = true
      account.signer = account.account
      account.via = 'baw'
      await savePrefs({ account: account.account, handle: account.handle, agent: true, via: 'baw' })
      return account
    }
    case 'CONNECT': {
      let session = await readAgentSession()
      const stored = await prefs()
      let account = await chooseAccount(session, stored)
      if (!account?.account) {
        const tab = await findTab()
        await focus(tab)
        session = await readAgentSession()
        account = await chooseAccount(session, stored)
      }
      if (!account?.account) {
        throw new Error('没有读到钱包。点「扫码登录」，用币安 App 连接 Agent 钱包。')
      }
      await savePrefs({
        account: account.account,
        handle: account.handle || '',
        agent: Boolean(account.agent),
        via: account.via || '',
      })
      return account
    }
    case 'DISCONNECT': {
      const stored = await prefs()
      delete stored.account
      delete stored.handle
      delete stored.agent
      delete stored.via
      await chrome.storage.local.set({ [KEY]: stored })
      return { ok: true }
    }
    case 'STATUS': {
      if (!isAddr(payload.account)) return null
      return readAccount(payload.account)
    }
    case 'MY_BOOK': {
      if (!isAddr(payload.account)) throw new Error('先连接 Agent 钱包')
      const known = payload.tokens || []
      const fx = known.find((row) => row.bnbUsd > 0)?.bnbUsd || 0
      const [book, spotted] = await Promise.all([
        bookRows(payload.account, known, fx),
        walletRows(payload.account, known, fx).catch(() => []),
      ])
      const merged = new Map()
      for (const row of [...book, ...spotted]) {
        if (!row?.address) continue
        const prev = merged.get(row.address)
        if (!prev) {
          merged.set(row.address, row)
          continue
        }
        const pnl = Number.isFinite(prev.unrealizedUsd) ? prev.unrealizedUsd : row.unrealizedUsd
        merged.set(row.address, {
          ...prev,
          ...row,
          posBalance: row.posBalance || prev.posBalance,
          valueUsd: Number(row.valueUsd) > 0 ? row.valueUsd : prev.valueUsd,
          unrealizedUsd: Number.isFinite(pnl) ? pnl : undefined,
        })
      }
      const positions = [...merged.values()]
      const seen = new Set(known.map((row) => String(row.address || '').toLowerCase()))
      const extra = positions.filter((row) => row.address && !seen.has(row.address))
      const addrs = [...new Set([
        ...positions.map((row) => row.address),
        ...known.map((row) => String(row.address || '').toLowerCase()),
      ])].filter((addr) => isAddr(addr))
      const balances = await holdingsOf(payload.account, addrs)
      const pnl = positions
        .filter((row) => Number.isFinite(Number(row.unrealizedUsd)))
        .map((row) => ({ address: row.address, unrealizedUsd: Number(row.unrealizedUsd) }))
      return { extra, balances, positions, pnl }
    }
    case 'PREVIEW': {
      const base = tradeInput(payload)
      if (payload.side === 'sell') {
        const pct = Math.min(100, Math.max(1, Math.round(Number(payload.pct) || 100)))
        return planSell({ ...base, pct })
      }
      return planBuy({ ...base, amountHuman: payload.amount, usd: payload.usd, quoteUsd: payload.quoteUsd })
    }
    case 'EXECUTE': {
      const plan = payload.plan || {}
      const hashes = await sendSteps(plan.steps, payload.account, plan.token, plan.quote, progress, plan.usd)
      return { hashes }
    }
    case 'SELL_ALL': {
      const account = payload.account
      if (!isAddr(account)) throw new Error('先连接 Agent 钱包')
      const rows = payload.rows || []
      if (!rows.length) throw new Error('没有可卖的持仓')
      const pct = Math.min(100, Math.max(1, Math.round(Number(payload.pct) || 100)))
      const slippageBps = parseSlippage(payload.slippage)
      const hashes = []
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i]
        progress(`卖出 ${i + 1}/${rows.length} ${row.symbol || row.address}`)
        const plan = await planSell({
          token: row.address,
          from: account,
          pct,
          slippageBps,
          hint: row.v2Launchpad || '',
          pair: row.pair || '',
          symbol: row.symbol || '',
          quoteSymbol: row.quoteSymbol || 'BNB',
          track: row.track || '',
        })
        const part = await sendSteps(plan.steps, account, plan.token, plan.quote, progress)
        hashes.push(...part)
      }
      return { hashes }
    }
    default:
      throw new Error('未知操作')
  }
}
