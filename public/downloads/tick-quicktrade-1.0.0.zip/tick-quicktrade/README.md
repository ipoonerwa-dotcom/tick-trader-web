# Tick 快速买卖

Tick Trader 出品的浏览器插件。不会用 AI 指令操作 Agent 钱包，也能在一个面板里买卖 GANG 平台的全部代币。

- 列表来自 gang.fun：热门、最新、进度、已毕业、持仓。$TICK 在热门榜置顶
- 还在内盘的币走 GANG 曲线；已经毕业的走 PancakeSwap V2。报价币不是 BNB 时会先自动换好
- 内盘买入只认持有 Agent ID 的钱包（币安 Agentic 钱包）。卖出和毕业后的交易不看这个
- 插件不保存私钥。每一笔都在币安钱包或币安 App 里确认
- 只会发往 GANG 内盘合约、PancakeSwap 路由、WBNB/USDT/USDC 和你正在买卖的那个币，别的合约一律拒绝

## 安装（Chrome / Edge）

1. 把压缩包解压到一个固定的文件夹（别放在下载或临时目录，删了插件就不能用了）
2. 要用 Agent 钱包下单：Windows 双击 `install-windows.bat`，Mac 双击 `install-mac.command`。只用浏览器里的 Binance Wallet 可以跳过这步
3. 完全退出浏览器（只关窗口不够），再重新打开
4. 打开 `chrome://extensions`，打开右上角「开发者模式」，点「加载已解压的扩展程序」，选这个文件夹。插件 ID 应该是 `jfokaabmchoeibmdmophekpbokgmgcle`
5. 打开 https://www.ticktraderai.io 或 https://gang.fun ，点右下角「买卖」；第一次用点面板右上角「扫码登录」，用币安 App 扫码

## 用法

买入金额和滑点在面板上方。点某一行的「买」或「卖」会先给出预计数量，确认后才发交易。卖出比例是 25% / 50% / 100%，「持仓」里可以按这个比例一次卖掉列出的持仓。搜索框输入完整合约地址后回车，可以交易列表里还没有的币。

## 卸载

在 `chrome://extensions` 移除插件。装过签名程序的话，再删掉这个文件夹：

- Windows：`%APPDATA%\TickQuickTrade`，以及注册表 `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.ticktrader.quicktrade`
- Mac：`~/Library/Application Support/TickQuickTrade`，以及 `~/Library/Application Support/Google/Chrome/NativeMessagingHosts/com.ticktrader.quicktrade.json`

交易功能基于 GANG 团队的快速买卖插件。
